package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.datasource.MockData
import com.example.data.model.Product
import com.example.ui.components.getCategoryIcon
import com.example.ui.theme.ShoporaBlack
import com.example.ui.theme.ShoporaBorderGray
import com.example.ui.theme.ShoporaGreen
import com.example.ui.theme.ShoporaLightGray
import com.example.ui.theme.ShoporaMediumGray
import com.example.ui.theme.ShoporaRed
import com.example.ui.theme.ShoporaYellow
import com.example.viewmodel.Screen
import com.example.viewmodel.ShopViewModel
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddProductScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit
) {
    val context = LocalContext.current

    // Form fields
    var productName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Mobiles") }
    var priceText by remember { mutableStateOf("") }
    var originalPriceText by remember { mutableStateOf("") }
    var brandName by remember { mutableStateOf("Alex's Boutique") }
    var descriptionText by remember { mutableStateOf("") }
    var stockText by remember { mutableStateOf("15") }
    var colorsInput by remember { mutableStateOf("") }
    var sizesInput by remember { mutableStateOf("") }
    var isFlashSale by remember { mutableStateOf(false) }
    var isTrending by remember { mutableStateOf(true) }

    // Images list
    val imagesList = remember { mutableStateListOf<String>() }
    var showUrlDialog by remember { mutableStateOf(false) }
    var customUrlInput by remember { mutableStateOf("") }

    // Specifications key-value list
    val specsList = remember {
        mutableStateListOf(
            Pair("Condition", "Brand New in Box"),
            Pair("Warranty", "1 Year Shopora Protection")
        )
    }
    var newSpecKey by remember { mutableStateOf("") }
    var newSpecValue by remember { mutableStateOf("") }

    // Validation state
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Zero-permission Android Photo Picker contract (Google Play compliant)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            imagesList.add(uri.toString())
            errorMessage = null
        }
    }

    // Curated high quality presets for instant 1-tap testing
    val samplePresets = listOf(
        Pair("iPhone 16 Pro", "https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=800&q=80"),
        Pair("Luxury Perfume", "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80"),
        Pair("Silk Dress", "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80"),
        Pair("Linen Overshirt", "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80"),
        Pair("Sneakers", "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80"),
        Pair("ANC Headphones", "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80")
    )

    val availableCategories = listOf(
        "Mobiles", "Perfumes", "Ladies Clothes", "Fashion",
        "Electronics", "Beauty", "Home", "Shoes", "Bags", "Watches", "Accessories"
    )

    val price = priceText.toDoubleOrNull() ?: 0.0
    val originalPrice = originalPriceText.toDoubleOrNull() ?: price
    val calculatedDiscount = if (originalPrice > price && originalPrice > 0.0) {
        (((originalPrice - price) / originalPrice) * 100).toInt()
    } else 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("add_product_screen")
    ) {
        // Top App Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp)
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "List a New Product",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Sell to millions of Shopora buyers",
                        fontSize = 11.sp,
                        color = ShoporaMediumGray
                    )
                }
                OutlinedButton(
                    onClick = { onNavigate(Screen.MyProducts) },
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Storefront,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = ShoporaBlack
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("My Listings", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ShoporaBlack)
                }
            }
        }

        // Form Body
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Error Alert Banner
            AnimatedVisibility(visible = errorMessage != null) {
                Surface(
                    color = ShoporaRed.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ShoporaRed.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = ShoporaRed,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { errorMessage = null },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = ShoporaRed, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // 1. PRODUCT IMAGES SECTION
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Product Photos *",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${imagesList.size} Photos",
                            fontSize = 12.sp,
                            color = if (imagesList.isEmpty()) ShoporaMediumGray else ShoporaGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        text = "Upload high quality photos from gallery or choose from quick e-commerce samples",
                        fontSize = 12.sp,
                        color = ShoporaMediumGray,
                        modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                    )

                    // Image Upload Buttons Row
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Open Device Photo Picker (Zero Permissions, Google Play compliant)
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = ShoporaBlack, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Upload Photo", color = ShoporaBlack, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        // Add by URL
                        OutlinedButton(
                            onClick = { showUrlDialog = !showUrlDialog },
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Link, contentDescription = null, tint = ShoporaBlack, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add via URL", color = ShoporaBlack, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }

                    // Direct Image URL Field (if toggled)
                    AnimatedVisibility(visible = showUrlDialog) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp)
                        ) {
                            OutlinedTextField(
                                value = customUrlInput,
                                onValueChange = { customUrlInput = it },
                                placeholder = { Text("Paste image URL (https://...)", fontSize = 12.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (customUrlInput.isNotBlank()) {
                                        imagesList.add(customUrlInput.trim())
                                        customUrlInput = ""
                                        showUrlDialog = false
                                        errorMessage = null
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ShoporaBlack)
                            ) {
                                Text("Add")
                            }
                        }
                    }

                    // Quick Sample Presets (for instant testing)
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Or choose sample product photo:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(samplePresets) { (presetName, presetUrl) ->
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = ShoporaLightGray,
                                border = androidx.compose.foundation.BorderStroke(1.dp, ShoporaBorderGray),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable {
                                        imagesList.add(presetUrl)
                                        errorMessage = null
                                    }
                            ) {
                                Text(
                                    text = "+ $presetName",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = ShoporaBlack,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // Selected Images Previews Carousel
                    if (imagesList.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Selected Images (${imagesList.size})",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(imagesList) { imgUrl ->
                                Box(
                                    modifier = Modifier
                                        .size(90.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(ShoporaLightGray)
                                ) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(context)
                                            .data(imgUrl)
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = "Selected image",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    // Remove button
                                    IconButton(
                                        onClick = { imagesList.remove(imgUrl) },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(4.dp)
                                            .size(24.dp)
                                            .background(ShoporaBlack.copy(alpha = 0.75f), CircleShape)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. PRODUCT DETAILS SECTION
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Product Details",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Product Name
                    OutlinedTextField(
                        value = productName,
                        onValueChange = { productName = it; errorMessage = null },
                        label = { Text("Product Title *") },
                        placeholder = { Text("e.g., iPhone 16 Pro, French Velvet Perfume, Silk Maxi Dress") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_product_name")
                    )

                    // Category Selector Chips
                    Column {
                        Text(
                            text = "Category *",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            availableCategories.forEach { cat ->
                                val isSelected = selectedCategory == cat
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = if (isSelected) ShoporaYellow else ShoporaLightGray,
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, ShoporaBlack) else null,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(18.dp))
                                        .clickable { selectedCategory = cat }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                    ) {
                                        Icon(
                                            imageVector = getCategoryIcon(cat),
                                            contentDescription = null,
                                            tint = ShoporaBlack,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = cat,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = ShoporaBlack
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Brand / Seller Name
                    OutlinedTextField(
                        value = brandName,
                        onValueChange = { brandName = it },
                        label = { Text("Brand / Store Name") },
                        placeholder = { Text("e.g., Apple, Aura Studio, Your Brand") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Description
                    OutlinedTextField(
                        value = descriptionText,
                        onValueChange = { descriptionText = it },
                        label = { Text("Description *") },
                        placeholder = { Text("Describe materials, features, craftsmanship, condition, and benefits...") },
                        minLines = 3,
                        maxLines = 6,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // 3. PRICING & INVENTORY
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Pricing & Inventory",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = priceText,
                            onValueChange = { priceText = it; errorMessage = null },
                            label = { Text("Selling Price ($) *") },
                            placeholder = { Text("0.00") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_product_price")
                        )

                        OutlinedTextField(
                            value = originalPriceText,
                            onValueChange = { originalPriceText = it },
                            label = { Text("Original Price ($)") },
                            placeholder = { Text("0.00") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (calculatedDiscount > 0) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = ShoporaYellow
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.LocalOffer, contentDescription = null, tint = ShoporaBlack, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Discount Badge: $calculatedDiscount% OFF will be shown to buyers!",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ShoporaBlack
                                )
                            }
                        }
                    }

                    // Stock Quantity
                    OutlinedTextField(
                        value = stockText,
                        onValueChange = { stockText = it },
                        label = { Text("Stock Quantity in Inventory") },
                        placeholder = { Text("10") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // 4. VARIATIONS (COLORS & SIZES)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Variations & Options",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    OutlinedTextField(
                        value = colorsInput,
                        onValueChange = { colorsInput = it },
                        label = { Text("Colors (comma separated)") },
                        placeholder = { Text("e.g., Natural Titanium, Desert Gold, Midnight") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = sizesInput,
                        onValueChange = { sizesInput = it },
                        label = { Text("Sizes / Storage (comma separated)") },
                        placeholder = { Text("e.g., 256GB, 512GB, 1TB or XS, S, M, L, XL") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // 5. CUSTOM SPECIFICATIONS
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Specifications Table",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Current Specs
                    specsList.forEachIndexed { index, (k, v) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ShoporaLightGray, RoundedCornerShape(10.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(text = k, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            Text(text = v, fontSize = 12.sp, color = ShoporaMediumGray, modifier = Modifier.weight(1.5f))
                            IconButton(
                                onClick = { specsList.removeAt(index) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Delete", tint = ShoporaMediumGray, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    // Add new spec row
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = newSpecKey,
                            onValueChange = { newSpecKey = it },
                            placeholder = { Text("Feature (e.g., Material)", fontSize = 12.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = newSpecValue,
                            onValueChange = { newSpecValue = it },
                            placeholder = { Text("Value (e.g., Grade 5 Titanium)", fontSize = 12.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1.2f)
                        )
                        IconButton(
                            onClick = {
                                if (newSpecKey.isNotBlank() && newSpecValue.isNotBlank()) {
                                    specsList.add(Pair(newSpecKey.trim(), newSpecValue.trim()))
                                    newSpecKey = ""
                                    newSpecValue = ""
                                }
                            },
                            modifier = Modifier
                                .size(42.dp)
                                .background(ShoporaYellow, RoundedCornerShape(12.dp))
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add", tint = ShoporaBlack)
                        }
                    }
                }
            }

            // 6. PROMOTIONAL TOGGLES
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Featured in Trending", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Promote this product on homepage trending carousels", fontSize = 11.sp, color = ShoporaMediumGray)
                        }
                        Switch(
                            checked = isTrending,
                            onCheckedChange = { isTrending = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = ShoporaBlack, checkedTrackColor = ShoporaYellow)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Enroll in Flash Sale", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Feature with countdown timer badges", fontSize = 11.sp, color = ShoporaMediumGray)
                        }
                        Switch(
                            checked = isFlashSale,
                            onCheckedChange = { isFlashSale = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = ShoporaBlack, checkedTrackColor = ShoporaYellow)
                        )
                    }
                }
            }

            // SUBMIT BUTTON
            Button(
                onClick = {
                    // Validations
                    if (productName.isBlank()) {
                        errorMessage = "Please enter a valid product name."
                        return@Button
                    }
                    if (price <= 0.0) {
                        errorMessage = "Please enter a valid selling price greater than $0."
                        return@Button
                    }
                    if (descriptionText.isBlank()) {
                        errorMessage = "Please enter a product description."
                        return@Button
                    }

                    // Fallback to beautiful category image if user didn't pick any
                    val finalImages = if (imagesList.isEmpty()) {
                        when (selectedCategory) {
                            "Mobiles" -> listOf("https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=800&q=80")
                            "Perfumes" -> listOf("https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80")
                            "Ladies Clothes" -> listOf("https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80")
                            "Fashion" -> listOf("https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80")
                            "Shoes" -> listOf("https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80")
                            "Watches" -> listOf("https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=800&q=80")
                            "Bags" -> listOf("https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80")
                            else -> listOf("https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80")
                        }
                    } else {
                        imagesList.toList()
                    }

                    val colorsList = colorsInput.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    val sizesList = sizesInput.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    val specsMap = specsList.toMap()
                    val stockCount = stockText.toIntOrNull() ?: 10

                    val newProduct = Product(
                        id = "user_prod_${UUID.randomUUID().toString().take(8)}",
                        name = productName.trim(),
                        category = selectedCategory,
                        price = price,
                        originalPrice = originalPrice,
                        discount = calculatedDiscount,
                        rating = 5.0f,
                        reviews = 1,
                        images = finalImages,
                        description = descriptionText.trim(),
                        specifications = specsMap,
                        colors = colorsList,
                        sizes = sizesList,
                        stock = stockCount,
                        brand = brandName.ifBlank { "Community Seller" },
                        isFeatured = true,
                        isTrending = isTrending,
                        isBestSeller = false,
                        isFlashSale = isFlashSale
                    )

                    viewModel.addUserProduct(newProduct)
                    onNavigate(Screen.MyProducts)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("publish_product_button")
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = ShoporaBlack, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Publish Product to Shopora",
                    color = ShoporaBlack,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
