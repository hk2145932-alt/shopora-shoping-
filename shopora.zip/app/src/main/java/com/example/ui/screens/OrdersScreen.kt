package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.TrackingStep
import com.example.ui.theme.ShoporaBlack
import com.example.ui.theme.ShoporaBorderGray
import com.example.ui.theme.ShoporaGreen
import com.example.ui.theme.ShoporaLightGray
import com.example.ui.theme.ShoporaMediumGray
import com.example.ui.theme.ShoporaOrange
import com.example.ui.theme.ShoporaRed
import com.example.ui.theme.ShoporaYellow
import com.example.viewmodel.Screen
import com.example.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit
) {
    val orders by viewModel.orders.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    var trackedOrder by remember { mutableStateOf<Order?>(null) }

    val filteredOrders = when (selectedTab) {
        1 -> orders.filter { it.status != OrderStatus.DELIVERED && it.status != OrderStatus.CANCELLED } // Active
        2 -> orders.filter { it.status == OrderStatus.DELIVERED } // Completed
        3 -> orders.filter { it.status == OrderStatus.CANCELLED } // Cancelled
        else -> orders
    }

    if (trackedOrder != null) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { trackedOrder = null },
            sheetState = sheetState,
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Tracking Order #${trackedOrder?.orderId}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = ShoporaBlack
                        )
                        Text(
                            text = "Estimated: ${trackedOrder?.estimatedDelivery}",
                            fontSize = 12.sp,
                            color = ShoporaGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    IconButton(onClick = { trackedOrder = null }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Timeline Steps
                trackedOrder?.trackingSteps?.forEachIndexed { index, step ->
                    TrackingStepRow(
                        step = step,
                        isLast = index == (trackedOrder?.trackingSteps?.size ?: 0) - 1
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = { trackedOrder = null },
                    colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close Tracking", color = ShoporaBlack, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("orders_screen")
    ) {
        // Top App Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = "My Orders",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Tabs: All, Active, Completed, Cancelled
                val tabs = listOf("All", "Active", "Completed", "Cancelled")
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = ShoporaBlack,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = ShoporaYellow,
                            height = 3.dp
                        )
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 13.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        )
                    }
                }
            }
        }

        if (filteredOrders.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(ShoporaLightGray)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingBag,
                            contentDescription = null,
                            tint = ShoporaMediumGray,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "No Orders in this category",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Your past purchases and live deliveries will be listed here.",
                        fontSize = 13.sp,
                        color = ShoporaMediumGray,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredOrders) { order ->
                    OrderHistoryCard(
                        order = order,
                        onTrackClick = { trackedOrder = order }
                    )
                }
            }
        }
    }
}

@Composable
fun OrderHistoryCard(
    order: Order,
    onTrackClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("order_card_${order.orderId}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Order ID & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Order #${order.orderId}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = ShoporaBlack
                    )
                    Text(
                        text = "Placed on ${order.date}",
                        fontSize = 11.sp,
                        color = ShoporaMediumGray
                    )
                }

                val (badgeBg, badgeTextColor) = when (order.status) {
                    OrderStatus.DELIVERED -> Pair(ShoporaGreen.copy(alpha = 0.15f), ShoporaGreen)
                    OrderStatus.SHIPPED, OrderStatus.OUT_FOR_DELIVERY -> Pair(ShoporaYellow.copy(alpha = 0.3f), ShoporaBlack)
                    OrderStatus.CANCELLED -> Pair(ShoporaRed.copy(alpha = 0.15f), ShoporaRed)
                    else -> Pair(ShoporaLightGray, ShoporaBlack)
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = badgeBg
                ) {
                    Text(
                        text = order.status.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = badgeTextColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Item Thumbnails
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(order.items) { item ->
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(ShoporaLightGray)
                    ) {
                        AsyncImage(
                            model = item.product.images.firstOrNull(),
                            contentDescription = item.product.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = ShoporaBorderGray)
            Spacer(modifier = Modifier.height(10.dp))

            // Bottom Actions: Total & Track Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${order.items.size} Item(s)",
                        fontSize = 11.sp,
                        color = ShoporaMediumGray
                    )
                    Text(
                        text = "$${String.format("%.2f", order.total)}",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = ShoporaBlack
                    )
                }

                Button(
                    onClick = onTrackClick,
                    colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Timeline,
                        contentDescription = null,
                        tint = ShoporaBlack,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Track Order",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = ShoporaBlack
                    )
                }
            }
        }
    }
}

@Composable
fun TrackingStepRow(step: TrackingStep, isLast: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            step.isCompleted -> ShoporaGreen
                            step.isCurrent -> ShoporaYellow
                            else -> ShoporaLightGray
                        }
                    )
            ) {
                if (step.isCompleted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                } else if (step.isCurrent) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(ShoporaBlack)
                    )
                }
            }

            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(38.dp)
                        .background(if (step.isCompleted) ShoporaGreen else ShoporaBorderGray)
                )
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.padding(bottom = 12.dp)) {
            Text(
                text = step.status.title,
                fontWeight = if (step.isCurrent) FontWeight.Bold else FontWeight.SemiBold,
                fontSize = 14.sp,
                color = ShoporaBlack
            )
            Text(
                text = step.description,
                fontSize = 12.sp,
                color = ShoporaMediumGray
            )
            Text(
                text = step.date,
                fontSize = 10.sp,
                color = ShoporaMediumGray
            )
        }
    }
}
