package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ShoporaBlack
import com.example.ui.theme.ShoporaBorderGray
import com.example.ui.theme.ShoporaLightGray
import com.example.ui.theme.ShoporaMediumGray
import com.example.ui.theme.ShoporaRed
import com.example.ui.theme.ShoporaYellow
import com.example.ui.theme.ShoporaYellowSoft
import com.example.viewmodel.Screen
import com.example.viewmodel.ShopViewModel

@Composable
fun ProfileScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit
) {
    val orders by viewModel.orders.collectAsState()
    val wishlistIds by viewModel.wishlistProductIds.collectAsState()
    val userProducts by viewModel.userProducts.collectAsState()

    var showLogoutDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Log Out of Shopora?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to log out? Your saved cart and addresses will remain safe.") },
            confirmButton = {
                TextButton(onClick = {
                    showLogoutDialog = false
                    onNavigate(Screen.Home)
                }) {
                    Text("Log Out", color = ShoporaRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("Cancel", color = ShoporaBlack)
                }
            }
        )
    }

    if (showTermsDialog) {
        AlertDialog(
            onDismissRequest = { showTermsDialog = false },
            title = { Text("Terms & Privacy Policy", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Shopora is committed to protecting your privacy and security. " +
                            "All transactions are encrypted with 256-bit SSL technology. " +
                            "We never sell or share your personal data with third-party advertisers."
                )
            },
            confirmButton = {
                TextButton(onClick = { showTermsDialog = false }) {
                    Text("Close", color = ShoporaBlack, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("profile_screen"),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // User Profile Header
        item {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(ShoporaYellow)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Avatar",
                            tint = ShoporaBlack,
                            modifier = Modifier.size(46.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Alex Morgan",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = "alex.morgan@example.com",
                        fontSize = 13.sp,
                        color = ShoporaMediumGray
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = ShoporaYellowSoft
                    ) {
                        Text(
                            text = "⭐ VIP Gold Member",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ShoporaBlack,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Quick Stats Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ProfileStatCard(label = "Orders", count = orders.size.toString(), modifier = Modifier.weight(1f))
                ProfileStatCard(label = "Wishlist", count = wishlistIds.size.toString(), modifier = Modifier.weight(1f))
                ProfileStatCard(label = "Coupons", count = "3 Active", modifier = Modifier.weight(1f))
                ProfileStatCard(label = "Points", count = "450", modifier = Modifier.weight(1f))
            }
        }

        // Seller Hub & Add Product Section
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(ShoporaYellow)
                            ) {
                                Icon(Icons.Default.Storefront, contentDescription = null, tint = ShoporaBlack, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Seller Hub", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                                Text("List and sell your own products", fontSize = 11.sp, color = ShoporaMediumGray)
                            }
                        }

                        Button(
                            onClick = { onNavigate(Screen.AddProduct) },
                            colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = ShoporaBlack, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Add Product", color = ShoporaBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = ShoporaBorderGray.copy(alpha = 0.5f))

                    ProfileMenuItem(
                        icon = Icons.Default.Inventory2,
                        title = "My Listed Products",
                        subtitle = "${userProducts.size} active products in store",
                        onClick = { onNavigate(Screen.MyProducts) }
                    )
                }
            }
        }

        // Menu Group 1: Commerce & Orders
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    ProfileMenuItem(
                        icon = Icons.Default.ReceiptLong,
                        title = "My Orders",
                        subtitle = "Track, return, or buy again",
                        onClick = { onNavigate(Screen.MyOrders) }
                    )
                    Divider(color = ShoporaBorderGray.copy(alpha = 0.5f))
                    ProfileMenuItem(
                        icon = Icons.Default.Favorite,
                        title = "Wishlist",
                        subtitle = "${wishlistIds.size} saved products",
                        onClick = { onNavigate(Screen.Wishlist) }
                    )
                    Divider(color = ShoporaBorderGray.copy(alpha = 0.5f))
                    ProfileMenuItem(
                        icon = Icons.Default.LocationOn,
                        title = "My Addresses",
                        subtitle = "Manage delivery addresses",
                        onClick = { onNavigate(Screen.Addresses) }
                    )
                    Divider(color = ShoporaBorderGray.copy(alpha = 0.5f))
                    ProfileMenuItem(
                        icon = Icons.Default.CreditCard,
                        title = "Payment Methods",
                        subtitle = "Saved cards & wallets",
                        onClick = { onNavigate(Screen.Checkout) }
                    )
                }
            }
        }

        // Menu Group 2: Support & Settings
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    ProfileMenuItem(
                        icon = Icons.Default.Notifications,
                        title = "Notifications",
                        subtitle = "Promos, order alerts",
                        onClick = { onNavigate(Screen.Notifications) }
                    )
                    Divider(color = ShoporaBorderGray.copy(alpha = 0.5f))
                    ProfileMenuItem(
                        icon = Icons.Default.HelpOutline,
                        title = "Help & Support",
                        subtitle = "FAQ and Live Customer Care",
                        onClick = { onNavigate(Screen.Support) }
                    )
                    Divider(color = ShoporaBorderGray.copy(alpha = 0.5f))
                    ProfileMenuItem(
                        icon = Icons.Default.Security,
                        title = "Privacy Policy & Terms",
                        subtitle = "Data protection & terms",
                        onClick = { showTermsDialog = true }
                    )
                    Divider(color = ShoporaBorderGray.copy(alpha = 0.5f))
                    ProfileMenuItem(
                        icon = Icons.Default.Logout,
                        title = "Log Out",
                        subtitle = "Exit your account session",
                        textColor = ShoporaRed,
                        onClick = { showLogoutDialog = true }
                    )
                }
            }
        }
    }
}

@Composable
fun ProfileStatCard(label: String, count: String, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp)
        ) {
            Text(
                text = count,
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                color = ShoporaBlack
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                color = ShoporaMediumGray
            )
        }
    }
}

@Composable
fun ProfileMenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    textColor: androidx.compose.ui.graphics.Color = ShoporaBlack,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(ShoporaLightGray)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (textColor == ShoporaRed) ShoporaRed else ShoporaBlack,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = textColor
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = ShoporaMediumGray
            )
        }

        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = ShoporaMediumGray,
            modifier = Modifier.size(20.dp)
        )
    }
}
