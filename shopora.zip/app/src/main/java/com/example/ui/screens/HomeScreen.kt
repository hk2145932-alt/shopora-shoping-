package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.datasource.MockData
import com.example.data.model.Product
import com.example.ui.components.CategoryCard
import com.example.ui.components.ProductCard
import com.example.ui.components.SearchBarWidget
import com.example.ui.components.ShoporaTopBar
import com.example.ui.theme.ShoporaBlack
import com.example.ui.theme.ShoporaBorderGray
import com.example.ui.theme.ShoporaDarkGray
import com.example.ui.theme.ShoporaLightGray
import com.example.ui.theme.ShoporaMediumGray
import com.example.ui.theme.ShoporaOrange
import com.example.ui.theme.ShoporaRed
import com.example.ui.theme.ShoporaYellow
import com.example.ui.theme.ShoporaYellowDark
import com.example.ui.theme.ShoporaYellowSoft
import com.example.viewmodel.Screen
import com.example.viewmodel.ShopViewModel

@Composable
fun HomeScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit
) {
    val wishlistIds by viewModel.wishlistProductIds.collectAsState()
    val recentlyViewedIds by viewModel.recentlyViewedIds.collectAsState()
    val userProducts by viewModel.userProducts.collectAsState()
    val unreadNotifs by viewModel.notifications.collectAsState()
    val unreadCount = unreadNotifs.count { !it.isRead }

    val allAvailableProducts = remember(userProducts) {
        userProducts + MockData.products
    }
    val flashSaleProducts = remember(allAvailableProducts) { allAvailableProducts.filter { it.isFlashSale } }
    val trendingProducts = remember(allAvailableProducts) { allAvailableProducts.filter { it.isTrending } }
    val bestSellerProducts = remember(allAvailableProducts) { allAvailableProducts.filter { it.isBestSeller } }
    val recommendedProducts = remember(allAvailableProducts) { allAvailableProducts.filter { it.isFeatured } }
    val mobileProducts = remember(allAvailableProducts) { allAvailableProducts.filter { it.category == "Mobiles" } }
    val perfumeProducts = remember(allAvailableProducts) { allAvailableProducts.filter { it.category == "Perfumes" } }
    val ladiesProducts = remember(allAvailableProducts) { allAvailableProducts.filter { it.category == "Ladies Clothes" } }
    val recentlyViewedProducts = remember(recentlyViewedIds, allAvailableProducts) {
        allAvailableProducts.filter { recentlyViewedIds.contains(it.id) }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .testTag("home_screen"),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
        // 1. Top Bar
        item {
            ShoporaTopBar(
                selectedAddressText = "New York, 10001",
                unreadNotificationsCount = unreadCount,
                onAddressClick = { onNavigate(Screen.Addresses) },
                onNotificationClick = { onNavigate(Screen.Notifications) },
                onProfileClick = { onNavigate(Screen.Profile) }
            )
        }

        // 2. Search Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                SearchBarWidget(
                    query = "",
                    onQueryChange = {},
                    onSearch = { query -> viewModel.submitSearch(query) },
                    readOnly = true,
                    onClick = { onNavigate(Screen.Search) },
                    onCameraClick = { onNavigate(Screen.Search) }
                )
            }
        }

        // 2b. Seller Hub Quick Action Banner
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ShoporaYellowSoft,
                border = androidx.compose.foundation.BorderStroke(1.dp, ShoporaYellow),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onNavigate(Screen.AddProduct) }
                    .testTag("seller_banner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(ShoporaYellow)
                        ) {
                            Icon(Icons.Default.Storefront, contentDescription = null, tint = ShoporaBlack, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Sell on Shopora", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ShoporaBlack)
                            Text("List & sell your own products to buyers", fontSize = 11.sp, color = ShoporaBlack.copy(alpha = 0.75f))
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = ShoporaBlack
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = ShoporaYellow, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Add Product", color = ShoporaYellow, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // 3. Horizontal Categories Section
        item {
            Column(modifier = Modifier.padding(top = 10.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Categories",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    TextButton(onClick = { onNavigate(Screen.Categories) }) {
                        Text(
                            text = "See All",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ShoporaYellowDark
                        )
                    }
                }

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(items = MockData.categories, key = { it.id }) { category ->
                        CategoryCard(
                            category = category,
                            isSelected = false,
                            onClick = { viewModel.openCategory(category.name) }
                        )
                    }
                }
            }
        }

        // 4. Hero Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = ShoporaBlack),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .clickable { viewModel.openCategory("Fashion") }
                        .testTag("hero_banner")
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Background Banner Image
                        Image(
                            painter = painterResource(id = R.drawable.shopora_banner),
                            contentDescription = "Big Sale Banner",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Dark Gradient Overlay for optimal readability
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            ShoporaBlack.copy(alpha = 0.85f),
                                            ShoporaBlack.copy(alpha = 0.35f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )

                        // Banner Content
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = ShoporaYellow
                            ) {
                                Text(
                                    text = "BIG SALE",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = ShoporaBlack,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Up to 50% OFF",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )

                            Text(
                                text = "Summer & Lifestyle Essentials",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = { viewModel.openCategory("Fashion") },
                                colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                                shape = RoundedCornerShape(20.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text(
                                    text = "Shop Now",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ShoporaBlack
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    tint = ShoporaBlack,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4b. Community & User Listed Products Section
        if (userProducts.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(ShoporaYellow)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Storefront,
                                    contentDescription = "Seller Hub",
                                    tint = ShoporaBlack,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Your Listed Products (${userProducts.size})",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { onNavigate(Screen.MyProducts) }) {
                                Text(
                                    text = "Manage",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = ShoporaYellowDark
                                )
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Button(
                                onClick = { onNavigate(Screen.AddProduct) },
                                colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                                shape = RoundedCornerShape(14.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = ShoporaBlack, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("+ Add", color = ShoporaBlack, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(items = userProducts, key = { it.id }) { product ->
                            ProductCard(
                                product = product,
                                isInWishlist = wishlistIds.contains(product.id),
                                onClick = { viewModel.openProductDetail(product.id) },
                                onWishlistToggle = { viewModel.toggleWishlist(product) },
                                onAddToCart = { viewModel.addToCart(product) },
                                modifier = Modifier.width(180.dp)
                            )
                        }
                    }
                }
            }
        }

        // 5. Flash Sale Section with Countdown Timer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(ShoporaOrange)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = "Flash Sale",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Flash Sale",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        // Isolated Countdown Timer (Recomposes independently without lagging HomeScreen)
                        FlashSaleCountdown(viewModel)
                    }

                    TextButton(onClick = { onNavigate(Screen.Categories) }) {
                        Text(
                            text = "See All",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ShoporaYellowDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(items = flashSaleProducts, key = { it.id }) { product ->
                        ProductCard(
                            product = product,
                            isInWishlist = wishlistIds.contains(product.id),
                            onClick = { viewModel.openProductDetail(product.id) },
                            onWishlistToggle = { viewModel.toggleWishlist(product) },
                            onAddToCart = { viewModel.addToCart(product) },
                            modifier = Modifier.width(180.dp)
                        )
                    }
                }
            }
        }

        // 6. Trending Products Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = "Trending",
                            tint = ShoporaRed,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Trending Products",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    TextButton(onClick = { onNavigate(Screen.Categories) }) {
                        Text(
                            text = "See All",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ShoporaYellowDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(items = trendingProducts, key = { it.id }) { product ->
                        ProductCard(
                            product = product,
                            isInWishlist = wishlistIds.contains(product.id),
                            onClick = { viewModel.openProductDetail(product.id) },
                            onWishlistToggle = { viewModel.toggleWishlist(product) },
                            onAddToCart = { viewModel.addToCart(product) },
                            modifier = Modifier.width(180.dp)
                        )
                    }
                }
            }
        }

        // 7. Best Sellers Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Best Sellers",
                            tint = ShoporaYellowDark,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Best Sellers",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    TextButton(onClick = { onNavigate(Screen.Categories) }) {
                        Text(
                            text = "See All",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ShoporaYellowDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(items = bestSellerProducts, key = { it.id }) { product ->
                        ProductCard(
                            product = product,
                            isInWishlist = wishlistIds.contains(product.id),
                            onClick = { viewModel.openProductDetail(product.id) },
                            onWishlistToggle = { viewModel.toggleWishlist(product) },
                            onAddToCart = { viewModel.addToCart(product) },
                            modifier = Modifier.width(180.dp)
                        )
                    }
                }
            }
        }

        // Mobiles & iPhone Series Section
        if (mobileProducts.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Smartphone,
                                contentDescription = "Mobiles",
                                tint = ShoporaBlack,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Mobiles & iPhone 16",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        TextButton(onClick = { viewModel.openCategory("Mobiles") }) {
                            Text(
                                text = "See All",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ShoporaYellowDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(items = mobileProducts, key = { it.id }) { product ->
                            ProductCard(
                                product = product,
                                isInWishlist = wishlistIds.contains(product.id),
                                onClick = { viewModel.openProductDetail(product.id) },
                                onWishlistToggle = { viewModel.toggleWishlist(product) },
                                onAddToCart = { viewModel.addToCart(product) },
                                modifier = Modifier.width(190.dp)
                            )
                        }
                    }
                }
            }
        }

        // Ladies Fashion & Clothes Section
        if (ladiesProducts.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Style,
                                contentDescription = "Ladies Clothes",
                                tint = ShoporaYellowDark,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Ladies Collection",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        TextButton(onClick = { viewModel.openCategory("Ladies Clothes") }) {
                            Text(
                                text = "See All",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ShoporaYellowDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(items = ladiesProducts, key = { it.id }) { product ->
                            ProductCard(
                                product = product,
                                isInWishlist = wishlistIds.contains(product.id),
                                onClick = { viewModel.openProductDetail(product.id) },
                                onWishlistToggle = { viewModel.toggleWishlist(product) },
                                onAddToCart = { viewModel.addToCart(product) },
                                modifier = Modifier.width(180.dp)
                            )
                        }
                    }
                }
            }
        }

        // Luxury Perfumes Section
        if (perfumeProducts.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Spa,
                                contentDescription = "Perfumes",
                                tint = ShoporaYellowDark,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Luxury Perfumes",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        TextButton(onClick = { viewModel.openCategory("Perfumes") }) {
                            Text(
                                text = "See All",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ShoporaYellowDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(items = perfumeProducts, key = { it.id }) { product ->
                            ProductCard(
                                product = product,
                                isInWishlist = wishlistIds.contains(product.id),
                                onClick = { viewModel.openProductDetail(product.id) },
                                onWishlistToggle = { viewModel.toggleWishlist(product) },
                                onAddToCart = { viewModel.addToCart(product) },
                                modifier = Modifier.width(180.dp)
                            )
                        }
                    }
                }
            }
        }

        // 8. Recommended For You Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Text(
                    text = "Recommended For You",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 2-Column Responsive Grid Simulation
                val chunked = recommendedProducts.take(6).chunked(2)
                chunked.forEach { pair ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        for (prod in pair) {
                            ProductCard(
                                product = prod,
                                isInWishlist = wishlistIds.contains(prod.id),
                                onClick = { viewModel.openProductDetail(prod.id) },
                                onWishlistToggle = { viewModel.toggleWishlist(prod) },
                                onAddToCart = { viewModel.addToCart(prod) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // 9. Recently Viewed (if available)
        if (recentlyViewedProducts.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Recently Viewed",
                            tint = ShoporaMediumGray,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Recently Viewed",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(items = recentlyViewedProducts, key = { it.id }) { product ->
                            ProductCard(
                                product = product,
                                isInWishlist = wishlistIds.contains(product.id),
                                onClick = { viewModel.openProductDetail(product.id) },
                                onWishlistToggle = { viewModel.toggleWishlist(product) },
                                onAddToCart = { viewModel.addToCart(product) },
                                modifier = Modifier.width(170.dp)
                            )
                        }
                    }
                }
            }
        }

        // 10. Promotional VIP Club Coupon Banner
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = ShoporaYellowSoft),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🎉 Claim $50 Voucher",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = ShoporaBlack
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Use code SHOPORA50 at checkout on orders over $150.",
                            fontSize = 12.sp,
                            color = ShoporaDarkGray
                        )
                    }

                    Button(
                        onClick = { viewModel.applyCoupon("SHOPORA50") },
                        colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy code",
                            tint = ShoporaBlack,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Apply",
                            color = ShoporaBlack,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }

        ExtendedFloatingActionButton(
            onClick = { onNavigate(Screen.AddProduct) },
            icon = { Icon(Icons.Default.Add, contentDescription = "Add Product", tint = ShoporaBlack) },
            text = { Text("Add Product", fontWeight = FontWeight.Bold, color = ShoporaBlack) },
            containerColor = ShoporaYellow,
            elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 16.dp)
                .testTag("fab_add_product")
        )
    }
}

@Composable
fun FlashSaleCountdown(viewModel: ShopViewModel) {
    val hours by viewModel.countdownHours.collectAsState()
    val minutes by viewModel.countdownMinutes.collectAsState()
    val seconds by viewModel.countdownSeconds.collectAsState()

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        TimerDigitBox(String.format("%02d", hours))
        Text(":", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        TimerDigitBox(String.format("%02d", minutes))
        Text(":", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        TimerDigitBox(String.format("%02d", seconds))
    }
}

@Composable
fun TimerDigitBox(digit: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = ShoporaBlack,
        modifier = Modifier.size(24.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = digit,
                color = ShoporaYellow,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}
