package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.datasource.MockData
import com.example.ui.theme.ShoporaBlack
import com.example.ui.theme.ShoporaBorderGray
import com.example.ui.theme.ShoporaLightGray
import com.example.ui.theme.ShoporaMediumGray
import com.example.ui.theme.ShoporaStar
import com.example.ui.theme.ShoporaYellow
import com.example.viewmodel.FilterState
import com.example.viewmodel.SortOption

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FilterBottomSheet(
    currentFilters: FilterState,
    currentSort: SortOption,
    onDismiss: () -> Unit,
    onApply: (FilterState, SortOption) -> Unit,
    onReset: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var tempCategory by remember { mutableStateOf(currentFilters.category) }
    var tempPriceRange by remember {
        mutableStateOf(currentFilters.minPrice.toFloat()..currentFilters.maxPrice.toFloat())
    }
    var tempRating by remember { mutableStateOf(currentFilters.minRating) }
    var tempDiscounted by remember { mutableStateOf(currentFilters.onlyDiscounted) }
    var tempSort by remember { mutableStateOf(currentSort) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        containerColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Filters & Sorting",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = ShoporaBlack
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sort Options
            Text(
                text = "Sort By",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = ShoporaBlack
            )
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SortOption.values().forEach { option ->
                    val isSelected = tempSort == option
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSelected) ShoporaYellow else ShoporaLightGray)
                            .then(
                                if (isSelected) Modifier.border(1.dp, ShoporaBlack, RoundedCornerShape(20.dp))
                                else Modifier
                            )
                            .clickable { tempSort = option }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = option.label,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = ShoporaBlack
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Categories
            Text(
                text = "Category",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = ShoporaBlack
            )
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // "All Categories" pill
                val isAllSelected = tempCategory == null
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isAllSelected) ShoporaYellow else ShoporaLightGray)
                        .clickable { tempCategory = null }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "All",
                        fontSize = 13.sp,
                        fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Medium,
                        color = ShoporaBlack
                    )
                }

                MockData.categories.forEach { cat ->
                    val isSelected = tempCategory.equals(cat.name, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSelected) ShoporaYellow else ShoporaLightGray)
                            .clickable { tempCategory = cat.name }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = cat.name,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = ShoporaBlack
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Price Range Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Price Range",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = ShoporaBlack
                )
                Text(
                    text = "$${tempPriceRange.start.toInt()} - $${tempPriceRange.endInclusive.toInt()}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ShoporaMediumGray
                )
            }

            RangeSlider(
                value = tempPriceRange,
                onValueChange = { tempPriceRange = it },
                valueRange = 0f..2500f,
                steps = 49,
                colors = SliderDefaults.colors(
                    thumbColor = ShoporaBlack,
                    activeTrackColor = ShoporaYellow,
                    inactiveTrackColor = ShoporaLightGray
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Minimum Rating
            Text(
                text = "Minimum Rating",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = ShoporaBlack
            )
            Spacer(modifier = Modifier.height(8.dp))

            val ratingOptions = listOf(0.0f to "Any", 4.0f to "4.0 ★ & up", 4.5f to "4.5 ★ & up", 4.8f to "4.8 ★ & up")
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ratingOptions.forEach { (rating, label) ->
                    val isSelected = tempRating == rating
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) ShoporaYellow else ShoporaLightGray)
                            .clickable { tempRating = rating }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = ShoporaBlack
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Only Discounted toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Discounted Items Only",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = ShoporaBlack
                )
                Switch(
                    checked = tempDiscounted,
                    onCheckedChange = { tempDiscounted = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = ShoporaBlack,
                        checkedTrackColor = ShoporaYellow
                    )
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        tempCategory = null
                        tempPriceRange = 0f..2500f
                        tempRating = 0f
                        tempDiscounted = false
                        tempSort = SortOption.POPULAR
                        onReset()
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("Reset All", color = ShoporaBlack, fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = {
                        onApply(
                            FilterState(
                                category = tempCategory,
                                minPrice = tempPriceRange.start.toDouble(),
                                maxPrice = tempPriceRange.endInclusive.toDouble(),
                                minRating = tempRating,
                                onlyDiscounted = tempDiscounted
                            ),
                            tempSort
                        )
                        onDismiss()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("apply_filter_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("Apply Filters", color = ShoporaBlack, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
