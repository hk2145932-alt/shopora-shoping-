package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ShoporaYellow = Color(0xFFFFD200)
val ShoporaYellowDark = Color(0xFFEAB308)
val ShoporaYellowDeep = Color(0xFFCA8A04)
val ShoporaYellowLight = Color(0xFFFEF08A)
val ShoporaYellowSoft = Color(0xFFFEF9C3)

val ShoporaBlack = Color(0xFF111827)
val ShoporaDarkGray = Color(0xFF1F2937)
val ShoporaMediumGray = Color(0xFF4B5563)
val ShoporaMutedGray = Color(0xFF9CA3AF)
val ShoporaBorderGray = Color(0xFFE5E7EB)
val ShoporaLightGray = Color(0xFFF3F4F6)
val ShoporaBackground = Color(0xFFF9FAFB)
val ShoporaSurface = Color(0xFFFFFFFF)

val ShoporaRed = Color(0xFFEF4444)
val ShoporaGreen = Color(0xFF10B981)
val ShoporaOrange = Color(0xFFF97316)
val ShoporaStar = Color(0xFFFBBF24)

// Dark mode colors
val ShoporaDarkBackground = Color(0xFF0F172A)
val ShoporaDarkSurface = Color(0xFF1E293B)
val ShoporaDarkSurfaceVariant = Color(0xFF334155)
val ShoporaDarkBorder = Color(0xFF475569)
