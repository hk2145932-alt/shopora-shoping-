package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = ShoporaYellowDark,
    onPrimary = ShoporaBlack,
    primaryContainer = ShoporaYellowLight,
    onPrimaryContainer = ShoporaBlack,
    secondary = ShoporaDarkGray,
    onSecondary = Color.White,
    secondaryContainer = ShoporaLightGray,
    onSecondaryContainer = ShoporaDarkGray,
    tertiary = ShoporaOrange,
    onTertiary = Color.White,
    background = ShoporaBackground,
    onBackground = ShoporaBlack,
    surface = ShoporaSurface,
    onSurface = ShoporaBlack,
    surfaceVariant = ShoporaLightGray,
    onSurfaceVariant = ShoporaDarkGray,
    outline = ShoporaBorderGray,
    error = ShoporaRed,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = ShoporaYellow,
    onPrimary = ShoporaBlack,
    primaryContainer = ShoporaYellowDeep,
    onPrimaryContainer = Color.White,
    secondary = ShoporaYellowLight,
    onSecondary = ShoporaBlack,
    secondaryContainer = ShoporaDarkSurfaceVariant,
    onSecondaryContainer = Color.White,
    tertiary = ShoporaOrange,
    onTertiary = Color.White,
    background = ShoporaDarkBackground,
    onBackground = Color.White,
    surface = ShoporaDarkSurface,
    onSurface = Color.White,
    surfaceVariant = ShoporaDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = ShoporaDarkBorder,
    error = ShoporaRed,
    onError = Color.White
)

@Composable
fun ShoporaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep signature Yellow & White branding
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
