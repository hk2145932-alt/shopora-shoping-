package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PhoneIphone
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductCategory
import com.example.ui.theme.ShoporaBlack
import com.example.ui.theme.ShoporaBorderGray
import com.example.ui.theme.ShoporaLightGray
import com.example.ui.theme.ShoporaYellow

@Composable
fun getCategoryIcon(name: String): ImageVector {
    return when (name.lowercase()) {
        "perfumes", "perfume", "fragrances" -> Icons.Default.Spa
        "ladies clothes", "women's fashion", "ladies" -> Icons.Default.Style
        "mobiles", "smartphones", "iphone" -> Icons.Default.Smartphone
        "fashion" -> Icons.Default.Checkroom
        "electronics" -> Icons.Default.Devices
        "beauty" -> Icons.Default.Face
        "home", "home & kitchen" -> Icons.Default.Home
        "shoes" -> Icons.Default.DirectionsWalk
        "bags" -> Icons.Default.ShoppingBag
        "watches" -> Icons.Default.Watch
        "kids" -> Icons.Default.ChildCare
        "sports" -> Icons.Default.FitnessCenter
        else -> Icons.Default.AutoAwesome
    }
}

@Composable
fun CategoryCard(
    category: ProductCategory,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(4.dp)
            .testTag("category_chip_${category.name.lowercase()}")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(if (isSelected) ShoporaYellow else ShoporaLightGray)
                .then(
                    if (isSelected) Modifier.border(2.dp, ShoporaBlack, CircleShape)
                    else Modifier.border(1.dp, ShoporaBorderGray, CircleShape)
                )
        ) {
            Icon(
                imageVector = getCategoryIcon(category.name),
                contentDescription = category.name,
                tint = if (isSelected) ShoporaBlack else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(28.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = category.name,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) ShoporaBlack else MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
    }
}
