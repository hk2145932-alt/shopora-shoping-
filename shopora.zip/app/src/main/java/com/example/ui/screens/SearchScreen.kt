package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.datasource.MockData
import com.example.ui.components.FilterBottomSheet
import com.example.ui.components.ProductCard
import com.example.ui.components.SearchBarWidget
import com.example.ui.theme.ShoporaBlack
import com.example.ui.theme.ShoporaBorderGray
import com.example.ui.theme.ShoporaLightGray
import com.example.ui.theme.ShoporaMediumGray
import com.example.ui.theme.ShoporaYellow
import com.example.viewmodel.Screen
import com.example.viewmodel.ShopViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit
) {
    val searchQuery by viewModel.searchQuery.collectAsState()
    val recentSearches by viewModel.recentSearches.collectAsState()
    val wishlistIds by viewModel.wishlistProductIds.collectAsState()
    val userProducts by viewModel.userProducts.collectAsState()
    val filterState by viewModel.filterState.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()

    var showFilterSheet by remember { mutableStateOf(false) }
    var selectedCategoryFilter by remember { mutableStateOf<String?>(null) }

    val popularSearches = listOf(
        "iPhone 16", "Perfume", "Ladies Clothes", "Silk Dress",
        "Mobiles", "Linen Shirt", "Watch", "Sneakers",
        "Vanilla Perfume", "Denim Jacket", "AirPods", "Trench Coat"
    )

    val searchCategories = listOf("All", "Mobiles", "Perfumes", "Ladies Clothes", "Fashion", "Electronics")

    // Reactive computation with immediate memoization
    val results = remember(searchQuery, selectedCategoryFilter, filterState, sortOption, userProducts) {
        if (searchQuery.isNotBlank() || selectedCategoryFilter != null) {
            val queryToRun = if (searchQuery.isNotBlank()) searchQuery else (selectedCategoryFilter ?: "")
            viewModel.searchProducts(queryToRun, selectedCategoryFilter)
        } else {
            emptyList()
        }
    }

    if (showFilterSheet) {
        FilterBottomSheet(
            currentFilters = filterState,
            currentSort = sortOption,
            onDismiss = { showFilterSheet = false },
            onApply = { newFilters, newSort ->
                viewModel.updateFilters(newFilters)
                viewModel.updateSort(newSort)
            },
            onReset = { viewModel.resetFilters() }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("search_screen")
    ) {
        // Search Header
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    SearchBarWidget(
                        query = searchQuery,
                        onQueryChange = { viewModel.updateSearchQuery(it) },
                        onSearch = { viewModel.submitSearch(it) },
                        placeholderText = "Search iPhone, Perfume, Clothes...",
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(onClick = { showFilterSheet = true }) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = "Filter",
                            tint = ShoporaBlack
                        )
                    }
                }

                // Quick Category Filters Carousel
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(searchCategories) { catName ->
                        val isSelected = if (catName == "All") selectedCategoryFilter == null else selectedCategoryFilter == catName
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) ShoporaYellow else ShoporaLightGray,
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, ShoporaBlack) else null,
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    selectedCategoryFilter = if (catName == "All") null else catName
                                }
                        ) {
                            Text(
                                text = catName,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = ShoporaBlack,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }
        }

        if (searchQuery.isBlank() && selectedCategoryFilter == null) {
            // Show Recent Searches & Popular Trending Searches
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                // Quick Category Jump Cards
                item {
                    Text(
                        text = "Browse Top Categories",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ShoporaLightGray,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    selectedCategoryFilter = "Mobiles"
                                    viewModel.updateSearchQuery("iPhone")
                                }
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp)
                            ) {
                                Text("📱", fontSize = 24.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("iPhones & Mobiles", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ShoporaLightGray,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    selectedCategoryFilter = "Perfumes"
                                    viewModel.updateSearchQuery("Perfume")
                                }
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp)
                            ) {
                                Text("✨", fontSize = 24.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Luxury Perfumes", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ShoporaLightGray,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    selectedCategoryFilter = "Ladies Clothes"
                                    viewModel.updateSearchQuery("Ladies Clothes")
                                }
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp)
                            ) {
                                Text("👗", fontSize = 24.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Ladies Clothes", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Recent Searches
                if (recentSearches.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = null,
                                    tint = ShoporaMediumGray,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Recent Searches",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                            TextButton(onClick = { viewModel.clearRecentSearches() }) {
                                Text(
                                    text = "Clear All",
                                    fontSize = 12.sp,
                                    color = ShoporaMediumGray
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            recentSearches.forEach { search ->
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = ShoporaLightGray,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .clickable { viewModel.submitSearch(search) }
                                ) {
                                    Text(
                                        text = search,
                                        fontSize = 13.sp,
                                        color = ShoporaBlack,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }

                // Popular Searches
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = ShoporaYellow,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Popular Searches",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        popularSearches.forEach { term ->
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = MaterialTheme.colorScheme.surface,
                                shadowElevation = 1.dp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable { viewModel.submitSearch(term) }
                            ) {
                                Text(
                                    text = "🔍 $term",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Search Results Section
            val queryDisplay = if (searchQuery.isNotBlank()) searchQuery else selectedCategoryFilter ?: ""
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${results.size} products found for \"$queryDisplay\"",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                TextButton(onClick = { showFilterSheet = true }) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = null,
                        tint = ShoporaBlack,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Sort & Filter",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ShoporaBlack
                    )
                }
            }

            if (results.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = ShoporaMediumGray,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No exact matches for \"$queryDisplay\"",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Try one of our popular collections below:",
                            fontSize = 13.sp,
                            color = ShoporaMediumGray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.updateSearchQuery("iPhone") },
                                colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow)
                            ) {
                                Text("iPhones", color = ShoporaBlack, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { viewModel.updateSearchQuery("Perfume") },
                                colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow)
                            ) {
                                Text("Perfumes", color = ShoporaBlack, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { viewModel.updateSearchQuery("Ladies Clothes") },
                                colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow)
                            ) {
                                Text("Clothes", color = ShoporaBlack, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    val chunked = results.chunked(2)
                    items(
                        items = chunked,
                        key = { pair -> pair.map { it.id }.joinToString("_") }
                    ) { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            for (prod in pair) {
                                ProductCard(
                                    product = prod,
                                    isInWishlist = wishlistIds.contains(prod.id),
                                    onClick = { viewModel.openProductDetail(prod.id) },
                                    onWishlistToggle = { viewModel.toggleWishlist(prod) },
                                    onAddToCart = { viewModel.addToCart(prod) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (pair.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}
