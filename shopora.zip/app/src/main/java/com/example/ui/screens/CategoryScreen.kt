package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.datasource.MockData
import com.example.ui.components.CategoryCard
import com.example.ui.components.FilterBottomSheet
import com.example.ui.components.ProductCard
import com.example.ui.components.SearchBarWidget
import com.example.ui.theme.ShoporaBlack
import com.example.ui.theme.ShoporaBorderGray
import com.example.ui.theme.ShoporaLightGray
import com.example.ui.theme.ShoporaMediumGray
import com.example.ui.theme.ShoporaYellow
import com.example.viewmodel.Screen
import com.example.viewmodel.ShopViewModel

@Composable
fun CategoryScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit
) {
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val filterState by viewModel.filterState.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()
    val wishlistIds by viewModel.wishlistProductIds.collectAsState()
    val userProducts by viewModel.userProducts.collectAsState()

    var showFilterSheet by remember { mutableStateOf(false) }

    val products = remember(userProducts, selectedCategory, filterState, sortOption) {
        viewModel.getFilteredProducts()
    }

    val activeFilterCount = (if (filterState.minRating > 0f) 1 else 0) +
            (if (filterState.onlyDiscounted) 1 else 0) +
            (if (filterState.maxPrice < 2500.0) 1 else 0)

    if (showFilterSheet) {
        FilterBottomSheet(
            currentFilters = filterState,
            currentSort = sortOption,
            onDismiss = { showFilterSheet = false },
            onApply = { newFilters, newSort ->
                viewModel.updateFilters(newFilters)
                viewModel.updateSort(newSort)
            },
            onReset = {
                viewModel.resetFilters()
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("category_screen")
    ) {
        // Top Header
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Text(
                        text = selectedCategory ?: "All Categories",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )

                    // Filter Button
                    OutlinedButton(
                        onClick = { showFilterSheet = true },
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp).testTag("filter_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (activeFilterCount > 0) {
                                    Badge(
                                        containerColor = ShoporaBlack,
                                        contentColor = ShoporaYellow
                                    ) {
                                        Text(text = activeFilterCount.toString(), fontSize = 10.sp)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "Filter",
                                tint = ShoporaBlack,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Filter",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ShoporaBlack
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { onNavigate(Screen.AddProduct) },
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp).testTag("category_add_product_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Product",
                            tint = ShoporaBlack,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Sell / Add",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = ShoporaBlack
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Search Widget
                SearchBarWidget(
                    query = "",
                    onQueryChange = {},
                    onSearch = { query -> viewModel.submitSearch(query) },
                    readOnly = true,
                    placeholderText = "Search in ${selectedCategory ?: "all products"}...",
                    onClick = { onNavigate(Screen.Search) }
                )
            }
        }

        // Horizontal Category Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // "All" item
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .padding(4.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .background(if (selectedCategory == null) ShoporaYellow else ShoporaLightGray)
                    ) {
                        Text(
                            text = "ALL",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = ShoporaBlack
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "All",
                        fontSize = 11.sp,
                        fontWeight = if (selectedCategory == null) FontWeight.Bold else FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            items(MockData.categories) { cat ->
                val isSelected = selectedCategory.equals(cat.name, ignoreCase = true)
                CategoryCard(
                    category = cat,
                    isSelected = isSelected,
                    onClick = {
                        if (isSelected) {
                            viewModel.setCategoryFilter(null)
                        } else {
                            viewModel.setCategoryFilter(cat.name)
                        }
                    }
                )
            }
        }

        // Active Sort indicator bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${products.size} Items found",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = ShoporaMediumGray
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.testTag("sort_indicator")
            ) {
                Icon(
                    imageVector = Icons.Default.Sort,
                    contentDescription = null,
                    tint = ShoporaMediumGray,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = sortOption.label,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ShoporaBlack
                )
            }
        }

        // Product Grid or Empty State
        if (products.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp)
                    .testTag("empty_state")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No Products Found",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Try adjusting or clearing your filters to see more results.",
                        fontSize = 13.sp,
                        color = ShoporaMediumGray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.resetFilters() },
                        colors = ButtonDefaults.buttonColors(containerColor = ShoporaYellow),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Reset Filters", color = ShoporaBlack, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                val chunked = products.chunked(2)
                items(
                    items = chunked,
                    key = { pair -> pair.map { it.id }.joinToString("_") }
                ) { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        for (prod in pair) {
                            ProductCard(
                                product = prod,
                                isInWishlist = wishlistIds.contains(prod.id),
                                onClick = { viewModel.openProductDetail(prod.id) },
                                onWishlistToggle = { viewModel.toggleWishlist(prod) },
                                onAddToCart = { viewModel.addToCart(prod) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}
