package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.Coil
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.example.ui.components.ShoporaBottomBar
import com.example.ui.screens.AddProductScreen
import com.example.ui.screens.AddressScreen
import com.example.ui.screens.CartScreen
import com.example.ui.screens.CategoryScreen
import com.example.ui.screens.CheckoutScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MyProductsScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.OrderSuccessScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SupportScreen
import com.example.ui.screens.WishlistScreen
import com.example.ui.theme.ShoporaBlack
import com.example.ui.theme.ShoporaLightGray
import com.example.ui.theme.ShoporaMediumGray
import com.example.ui.theme.ShoporaRed
import com.example.ui.theme.ShoporaTheme
import com.example.ui.theme.ShoporaYellow
import com.example.viewmodel.Screen
import com.example.viewmodel.ShopViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize optimized Coil image caching for zero-glitch smooth rendering
        try {
            val imageLoader = ImageLoader.Builder(this)
                .memoryCache {
                    MemoryCache.Builder(this)
                        .maxSizePercent(0.25)
                        .build()
                }
                .diskCache {
                    DiskCache.Builder()
                        .directory(cacheDir.resolve("shopora_image_cache"))
                        .maxSizeBytes(50L * 1024 * 1024)
                        .build()
                }
                .crossfade(true)
                .respectCacheHeaders(false)
                .build()
            Coil.setImageLoader(imageLoader)
        } catch (_: Exception) {
        }

        enableEdgeToEdge()
        setContent {
            ShoporaTheme {
                ShoporaApp()
            }
        }
    }
}

@Composable
fun ShoporaApp(viewModel: ShopViewModel = viewModel()) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()
    val wishlistIds by viewModel.wishlistProductIds.collectAsState()

    val totalCartCount = cartItems.sumOf { it.quantity }
    val totalWishlistCount = wishlistIds.size

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(viewModel) {
        viewModel.toastMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // System back handler: pop screen stack when not on home
    BackHandler(enabled = currentScreen !is Screen.Home) {
        viewModel.navigateBack()
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth > 600.dp

        // Show bottom navigation bar on major browsing screens to prevent layout jumps
        val showBottomBar = !isWideScreen && (
                currentScreen is Screen.Home ||
                        currentScreen is Screen.Categories ||
                        currentScreen is Screen.Search ||
                        currentScreen is Screen.Cart ||
                        currentScreen is Screen.Wishlist ||
                        currentScreen is Screen.Profile
                )

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                if (isWideScreen) {
                    DesktopNavBar(
                        currentScreen = currentScreen,
                        cartCount = totalCartCount,
                        wishlistCount = totalWishlistCount,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }
            },
            bottomBar = {
                if (showBottomBar) {
                    ShoporaBottomBar(
                        currentScreen = currentScreen,
                        cartCount = totalCartCount,
                        wishlistCount = totalWishlistCount,
                        onNavigate = { viewModel.navigateTo(it) },
                        modifier = Modifier.testTag("bottom_nav_bar")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(
                    targetState = currentScreen,
                    animationSpec = tween(150),
                    label = "ScreenTransition"
                ) { target ->
                    when (target) {
                        is Screen.Home -> HomeScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.Categories -> CategoryScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.Search -> SearchScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.Cart -> CartScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.Wishlist -> WishlistScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.Profile -> ProfileScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.ProductDetail -> ProductDetailScreen(target.productId, viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.Checkout -> CheckoutScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.OrderSuccess -> OrderSuccessScreen(target.orderId, viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.MyOrders -> OrdersScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.OrderDetail -> OrdersScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.Addresses -> AddressScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.Notifications -> NotificationsScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.Support -> SupportScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.AddProduct -> AddProductScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                        is Screen.MyProducts -> MyProductsScreen(viewModel, onNavigate = { viewModel.navigateTo(it) })
                    }
                }
            }
        }
    }
}

@Composable
fun DesktopNavBar(
    currentScreen: Screen,
    cartCount: Int,
    wishlistCount: Int,
    onNavigate: (Screen) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 3.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onNavigate(Screen.Home) }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(ShoporaYellow)
                ) {
                    Icon(
                        imageVector = Icons.Default.ShoppingBag,
                        contentDescription = "Logo",
                        tint = ShoporaBlack,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Shopora",
                    fontWeight = FontWeight.Black,
                    fontSize = 22.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Desktop Nav Links
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                DesktopNavLink("Home", currentScreen is Screen.Home) { onNavigate(Screen.Home) }
                DesktopNavLink("Categories", currentScreen is Screen.Categories) { onNavigate(Screen.Categories) }
                DesktopNavLink("Search", currentScreen is Screen.Search) { onNavigate(Screen.Search) }
                DesktopNavLink("Sell / Add Product", currentScreen is Screen.AddProduct || currentScreen is Screen.MyProducts) { onNavigate(Screen.AddProduct) }
            }

            // Action Icons (Wishlist, Cart, Profile)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { onNavigate(Screen.Wishlist) }) {
                    BadgedBox(
                        badge = {
                            if (wishlistCount > 0) {
                                Badge(containerColor = ShoporaRed, contentColor = Color.White) {
                                    Text(text = wishlistCount.toString(), fontSize = 10.sp)
                                }
                            }
                        }
                    ) {
                        Icon(imageVector = Icons.Default.Favorite, contentDescription = "Wishlist")
                    }
                }

                IconButton(onClick = { onNavigate(Screen.Cart) }) {
                    BadgedBox(
                        badge = {
                            if (cartCount > 0) {
                                Badge(containerColor = ShoporaRed, contentColor = Color.White) {
                                    Text(text = cartCount.toString(), fontSize = 10.sp)
                                }
                            }
                        }
                    ) {
                        Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = "Cart")
                    }
                }

                IconButton(onClick = { onNavigate(Screen.Profile) }) {
                    Icon(imageVector = Icons.Default.Person, contentDescription = "Account")
                }
            }
        }
    }
}

@Composable
fun DesktopNavLink(title: String, isSelected: Boolean, onClick: () -> Unit) {
    Text(
        text = title,
        fontSize = 14.sp,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        color = if (isSelected) ShoporaBlack else ShoporaMediumGray,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}
