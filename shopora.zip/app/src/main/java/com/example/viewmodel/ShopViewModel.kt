package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.datasource.MockData
import com.example.data.model.Address
import com.example.data.model.CartItem
import com.example.data.model.ChatMessage
import com.example.data.model.Coupon
import com.example.data.model.NotificationItem
import com.example.data.model.Order
import com.example.data.model.Product
import com.example.data.repository.ShopRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

sealed class Screen {
    object Home : Screen()
    object Categories : Screen()
    object Search : Screen()
    object Cart : Screen()
    object Wishlist : Screen()
    object Profile : Screen()
    data class ProductDetail(val productId: String) : Screen()
    object Checkout : Screen()
    data class OrderSuccess(val orderId: String) : Screen()
    object MyOrders : Screen()
    data class OrderDetail(val orderId: String) : Screen()
    object Addresses : Screen()
    object Notifications : Screen()
    object Support : Screen()
    object AddProduct : Screen()
    object MyProducts : Screen()
}

enum class SortOption(val label: String) {
    POPULAR("Popular"),
    NEWEST("Newest"),
    PRICE_LOW_TO_HIGH("Price: Low to High"),
    PRICE_HIGH_TO_LOW("Price: High to Low"),
    HIGHEST_RATED("Highest Rated")
}

data class FilterState(
    val category: String? = null,
    val minPrice: Double = 0.0,
    val maxPrice: Double = 2500.0,
    val minRating: Float = 0.0f,
    val onlyDiscounted: Boolean = false,
    val brand: String? = null
)

class ShopViewModel(application: Application) : AndroidViewModel(application) {

    val repository = ShopRepository(application.applicationContext)

    // Navigation back stack
    private val _screenStack = MutableStateFlow<List<Screen>>(listOf(Screen.Home))
    val currentScreen: StateFlow<Screen> = _screenStack.combine(MutableStateFlow(Unit)) { stack, _ ->
        stack.lastOrNull() ?: Screen.Home
    }.stateIn(viewModelScope, SharingStarted.Eagerly, Screen.Home)

    // SnackBar / Toast events
    private val _toastMessage = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    // Repository flows
    val cartItems: StateFlow<List<CartItem>> = repository.cartItems
    val wishlistProductIds: StateFlow<Set<String>> = repository.wishlistProductIds
    val recentlyViewedIds: StateFlow<List<String>> = repository.recentlyViewedIds
    val orders: StateFlow<List<Order>> = repository.orders
    val addresses: StateFlow<List<Address>> = repository.addresses
    val notifications: StateFlow<List<NotificationItem>> = repository.notifications
    val recentSearches: StateFlow<List<String>> = repository.recentSearches
    val appliedCoupon: StateFlow<Coupon?> = repository.appliedCoupon
    val userProducts: StateFlow<List<Product>> = repository.userProducts

    // Filter & Search states
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()

    private val _filterState = MutableStateFlow(FilterState())
    val filterState: StateFlow<FilterState> = _filterState.asStateFlow()

    private val _sortOption = MutableStateFlow(SortOption.POPULAR)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    // Flash sale countdown timer (Hours, Mins, Secs)
    private val _countdownHours = MutableStateFlow(8)
    val countdownHours: StateFlow<Int> = _countdownHours.asStateFlow()
    private val _countdownMinutes = MutableStateFlow(42)
    val countdownMinutes: StateFlow<Int> = _countdownMinutes.asStateFlow()
    private val _countdownSeconds = MutableStateFlow(19)
    val countdownSeconds: StateFlow<Int> = _countdownSeconds.asStateFlow()

    // Live chat support state
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage("1", "support", "Hello! Welcome to Shopora Customer Care. How can we help you today?", "Just now", false)
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    init {
        startFlashSaleTimer()
    }

    private fun startFlashSaleTimer() {
        viewModelScope.launch {
            while (true) {
                delay(1000)
                var s = _countdownSeconds.value - 1
                var m = _countdownMinutes.value
                var h = _countdownHours.value

                if (s < 0) {
                    s = 59
                    m -= 1
                    if (m < 0) {
                        m = 59
                        h -= 1
                        if (h < 0) {
                            h = 12
                        }
                    }
                }
                _countdownSeconds.value = s
                _countdownMinutes.value = m
                _countdownHours.value = h
            }
        }
    }

    // Navigation methods
    fun navigateTo(screen: Screen) {
        val stack = _screenStack.value.toMutableList()
        // If clicking same tab as root (Home, Categories, Cart, Wishlist, Profile), reset to it
        if (screen is Screen.Home && stack.size > 1) {
            _screenStack.value = listOf(Screen.Home)
            return
        }
        if (stack.lastOrNull() != screen) {
            stack.add(screen)
            _screenStack.value = stack
        }
    }

    fun navigateBack(): Boolean {
        val stack = _screenStack.value.toMutableList()
        return if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            _screenStack.value = stack
            true
        } else {
            false
        }
    }

    fun openProductDetail(productId: String) {
        repository.recordRecentlyViewed(productId)
        navigateTo(Screen.ProductDetail(productId))
    }

    fun openCategory(categoryName: String) {
        _selectedCategory.value = categoryName
        _filterState.value = _filterState.value.copy(category = categoryName)
        navigateTo(Screen.Categories)
    }

    // Search & Filter
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun submitSearch(query: String) {
        _searchQuery.value = query
        repository.addSearchQuery(query)
        navigateTo(Screen.Search)
    }

    fun setCategoryFilter(category: String?) {
        _selectedCategory.value = category
        _filterState.value = _filterState.value.copy(category = category)
    }

    fun updateFilters(newFilters: FilterState) {
        _filterState.value = newFilters
    }

    fun updateSort(option: SortOption) {
        _sortOption.value = option
    }

    fun resetFilters() {
        _filterState.value = FilterState()
        _sortOption.value = SortOption.POPULAR
    }

    // Dedicated Intelligent Fault-Tolerant Search across ALL products
    fun searchProducts(query: String, filterCategory: String? = null): List<Product> {
        val cleanQuery = query.trim().lowercase(Locale.ROOT)
        if (cleanQuery.isEmpty()) return emptyList()

        // Normalize common user variations, spacings, and typos
        val normalizedQuery = cleanQuery
            .replace("ladeis", "ladies")
            .replace("ladie", "ladies")
            .replace("i phone", "iphone")
            .replace("iphne", "iphone")
            .replace("iphoen", "iphone")
            .replace("perfums", "perfume")
            .replace("perfumes", "perfume")
            .replace("parfume", "parfum")

        val rawTerms = normalizedQuery.split("[\\s,.-]+".toRegex()).filter { it.isNotBlank() }
        val unifiedQuery = normalizedQuery.replace(" ", "")

        val isPhoneQuery = unifiedQuery.contains("iphone") || unifiedQuery.contains("phone") ||
                unifiedQuery.contains("mobile") || unifiedQuery.contains("apple") ||
                rawTerms.any { it in listOf("phone", "iphone", "mobile", "apple", "magsafe", "ios", "airpods") }

        val isPerfumeQuery = unifiedQuery.contains("perfume") || unifiedQuery.contains("fragrance") ||
                unifiedQuery.contains("scent") || unifiedQuery.contains("cologne") || unifiedQuery.contains("parfum") ||
                rawTerms.any { it in listOf("perfume", "fragrance", "scent", "cologne", "parfum", "oud", "vanilla", "santal") }

        val isLadiesQuery = unifiedQuery.contains("ladies") || unifiedQuery.contains("women") ||
                rawTerms.any { it in listOf("ladies", "women", "woman", "dress", "culotte", "culottes", "skirt", "blouse", "gown") }

        val isClothesQuery = isLadiesQuery || unifiedQuery.contains("cloth") || unifiedQuery.contains("dress") ||
                unifiedQuery.contains("shirt") || unifiedQuery.contains("jacket") ||
                unifiedQuery.contains("blazer") || unifiedQuery.contains("trouser") ||
                unifiedQuery.contains("pant") || unifiedQuery.contains("sweater") ||
                unifiedQuery.contains("hoodie") || unifiedQuery.contains("trench") ||
                rawTerms.any { it in listOf("clothes", "clothing", "wear", "apparel", "shirt", "pants", "jeans", "hoodie", "jacket", "coat", "denim") }

        val isThinQuery = unifiedQuery.contains("think") || unifiedQuery.contains("thin") || unifiedQuery.contains("slim") || unifiedQuery.contains("smooth")

        val filters = _filterState.value
        val sort = _sortOption.value

        val scored = repository.getAllProducts().mapNotNull { prod ->
            val name = prod.name.lowercase(Locale.ROOT)
            val nameUnified = name.replace(" ", "")
            val category = prod.category.lowercase(Locale.ROOT)
            val brand = prod.brand.lowercase(Locale.ROOT)
            val desc = prod.description.lowercase(Locale.ROOT)

            var score = 0

            // Direct full query match
            if (name.contains(cleanQuery) || name.contains(normalizedQuery)) score += 120
            if (nameUnified.contains(unifiedQuery)) score += 100
            if (category.contains(cleanQuery) || category.contains(normalizedQuery)) score += 80
            if (brand.contains(cleanQuery) || brand.contains(normalizedQuery)) score += 70
            if (desc.contains(cleanQuery) || desc.contains(normalizedQuery)) score += 40

            // Semantic and category synonyms
            if (isPhoneQuery && (category.contains("mobile") || name.contains("iphone") || brand.contains("apple") || name.contains("phone") || desc.contains("iphone"))) {
                score += 90
            }
            if (isPerfumeQuery && (category.contains("perfume") || name.contains("parfum") || name.contains("cologne") || desc.contains("fragrance") || desc.contains("extrait"))) {
                score += 90
            }
            if (isLadiesQuery && (category.contains("ladies") || name.contains("dress") || name.contains("skirt") || name.contains("blouse") || name.contains("gown") || desc.contains("women"))) {
                score += 90
            }
            if (isClothesQuery && (category.contains("fashion") || category.contains("ladies") || name.contains("shirt") || name.contains("jacket") || name.contains("trousers") || name.contains("hoodie") || name.contains("sweater") || name.contains("overcoat"))) {
                score += 70
            }
            if (isThinQuery && (name.contains("slim") || name.contains("ultra-thin") || desc.contains("thin") || desc.contains("slim") || desc.contains("titanium") || desc.contains("smooth"))) {
                score += 50
            }

            // Word term matching
            for (term in rawTerms) {
                if (term.length <= 1) continue
                val stem = term.removeSuffix("s").removeSuffix("es")
                if (name.contains(term) || name.contains(stem)) score += 30
                if (category.contains(term) || category.contains(stem)) score += 25
                if (brand.contains(term) || brand.contains(stem)) score += 20
                if (desc.contains(term) || desc.contains(stem)) score += 10
            }

            // Check if specific category chip was tapped inside search
            val matchesSearchCategory = filterCategory == null || prod.category.equals(filterCategory, ignoreCase = true)
            if (!matchesSearchCategory) score = 0

            if (score > 0) Pair(prod, score) else null
        }

        // Apply price / rating filters
        var list = scored.filter { (prod, _) ->
            val matchesPrice = prod.price in filters.minPrice..filters.maxPrice
            val matchesRating = prod.rating >= filters.minRating
            val matchesDiscount = !filters.onlyDiscounted || prod.discount > 0
            matchesPrice && matchesRating && matchesDiscount
        }.sortedByDescending { it.second }.map { it.first }

        // If filters eliminated all items, fall back to score-ranked list to avoid 0 results
        if (list.isEmpty() && scored.isNotEmpty()) {
            list = scored.sortedByDescending { it.second }.map { it.first }
        }

        list = when (sort) {
            SortOption.POPULAR -> list.sortedByDescending { it.reviews }
            SortOption.NEWEST -> list.reversed()
            SortOption.PRICE_LOW_TO_HIGH -> list.sortedBy { it.price }
            SortOption.PRICE_HIGH_TO_LOW -> list.sortedByDescending { it.price }
            SortOption.HIGHEST_RATED -> list.sortedByDescending { it.rating }
        }

        return list
    }

    // Filtered products list for Category browsing
    fun getFilteredProducts(categoryOverride: String? = null, queryOverride: String? = null): List<Product> {
        if (!queryOverride.isNullOrBlank()) {
            return searchProducts(queryOverride)
        }

        val activeCategory = categoryOverride ?: _selectedCategory.value ?: _filterState.value.category
        val filters = _filterState.value
        val sort = _sortOption.value

        var list = repository.getAllProducts().filter { prod ->
            val matchesCategory = activeCategory.isNullOrBlank() || prod.category.equals(activeCategory, ignoreCase = true)
            val matchesPrice = prod.price in filters.minPrice..filters.maxPrice
            val matchesRating = prod.rating >= filters.minRating
            val matchesDiscount = !filters.onlyDiscounted || prod.discount > 0
            val matchesBrand = filters.brand.isNullOrBlank() || prod.brand.equals(filters.brand, ignoreCase = true)

            matchesCategory && matchesPrice && matchesRating && matchesDiscount && matchesBrand
        }

        list = when (sort) {
            SortOption.POPULAR -> list.sortedByDescending { it.reviews }
            SortOption.NEWEST -> list.reversed()
            SortOption.PRICE_LOW_TO_HIGH -> list.sortedBy { it.price }
            SortOption.PRICE_HIGH_TO_LOW -> list.sortedByDescending { it.price }
            SortOption.HIGHEST_RATED -> list.sortedByDescending { it.rating }
        }

        return list
    }

    // User Product Actions
    fun addUserProduct(product: Product) {
        repository.addUserProduct(product)
        showToast("Product '${product.name}' listed successfully!")
    }

    fun deleteUserProduct(productId: String) {
        repository.deleteUserProduct(productId)
        showToast("Product listing removed")
    }

    fun getProductById(id: String): Product? {
        return repository.getProductById(id)
    }

    fun getAllProducts(): List<Product> {
        return repository.getAllProducts()
    }

    // Cart actions
    fun addToCart(product: Product, color: String = "", size: String = "", quantity: Int = 1) {
        repository.addToCart(product, color, size, quantity)
        showToast("Added '${product.name}' to cart")
    }

    fun buyNow(product: Product, color: String = "", size: String = "", quantity: Int = 1) {
        repository.addToCart(product, color, size, quantity)
        navigateTo(Screen.Checkout)
    }

    fun updateCartQuantity(cartItemId: String, newQuantity: Int) {
        repository.updateCartQuantity(cartItemId, newQuantity)
    }

    fun removeFromCart(cartItemId: String) {
        repository.removeFromCart(cartItemId)
        showToast("Item removed from cart")
    }

    fun clearCart() {
        repository.clearCart()
        showToast("Cart cleared")
    }

    // Wishlist actions
    fun toggleWishlist(product: Product) {
        val wasInWishlist = repository.isInWishlist(product.id)
        repository.toggleWishlist(product.id)
        if (wasInWishlist) {
            showToast("Removed from wishlist")
        } else {
            showToast("Added '${product.name}' to wishlist")
        }
    }

    fun isProductInWishlist(productId: String): Boolean {
        return wishlistProductIds.value.contains(productId)
    }

    // Coupon
    fun applyCoupon(code: String) {
        val (success, message) = repository.applyCoupon(code)
        showToast(message)
    }

    fun removeCoupon() {
        repository.removeCoupon()
        showToast("Coupon removed")
    }

    // Checkout & Order
    fun placeOrder(
        customerName: String,
        customerPhone: String,
        address: Address,
        paymentMethod: String
    ) {
        if (cartItems.value.isEmpty()) {
            showToast("Your cart is empty!")
            return
        }
        val order = repository.placeOrder(
            customerName = customerName,
            customerPhone = customerPhone,
            address = address,
            paymentMethod = paymentMethod
        )
        // Navigate to Order Success Screen
        _screenStack.value = listOf(Screen.Home, Screen.OrderSuccess(order.orderId))
    }

    // Addresses
    fun addAddress(address: Address) {
        repository.addAddress(address)
        showToast("Address saved")
    }

    fun deleteAddress(id: String) {
        repository.deleteAddress(id)
        showToast("Address removed")
    }

    fun setDefaultAddress(id: String) {
        repository.setDefaultAddress(id)
        showToast("Default address updated")
    }

    // Notifications
    fun markAllNotificationsRead() {
        repository.markAllNotificationsRead()
        showToast("All notifications marked as read")
    }

    fun markNotificationRead(id: String) {
        repository.markNotificationRead(id)
    }

    // Search History
    fun clearRecentSearches() {
        repository.clearSearchHistory()
    }

    // Chat Support
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        val userMsg = ChatMessage(UUID.randomUUID().toString(), "user", text, "Just now", true)
        _chatMessages.value = _chatMessages.value + userMsg

        // Mock auto-reply
        viewModelScope.launch {
            delay(1200)
            val replyText = when {
                text.contains("order", ignoreCase = true) || text.contains("track", ignoreCase = true) ->
                    "You can view live order tracking in the 'My Orders' section anytime! Your recent order is currently in transit."
                text.contains("return", ignoreCase = true) || text.contains("refund", ignoreCase = true) ->
                    "We offer 30-day free returns. Simply select the order from 'My Orders' and tap 'Request Return' for an instant pickup label."
                text.contains("coupon", ignoreCase = true) || text.contains("discount", ignoreCase = true) ->
                    "You can use code 'SHOPORA50' for $50 off orders above $150, or 'FLASH20' for 20% off!"
                else -> "Thanks for reaching out! A Shopora representative will also assist you shortly if needed. How else can we help?"
            }
            val replyMsg = ChatMessage(UUID.randomUUID().toString(), "support", replyText, "Just now", false)
            _chatMessages.value = _chatMessages.value + replyMsg
        }
    }

    private fun showToast(msg: String) {
        _toastMessage.tryEmit(msg)
    }
}
