package com.example.data.model

data class CartItem(
    val id: String,
    val product: Product,
    val selectedColor: String = "",
    val selectedSize: String = "",
    val quantity: Int = 1
)

data class Address(
    val id: String,
    val label: String = "Home",
    val fullName: String,
    val phone: String,
    val street: String,
    val city: String,
    val province: String,
    val postalCode: String,
    val isDefault: Boolean = false
) {
    val fullAddressText: String
        get() = "$street, $city, $province $postalCode"
}

enum class OrderStatus(val title: String) {
    PENDING("Pending"),
    CONFIRMED("Confirmed"),
    PROCESSING("Processing"),
    SHIPPED("Shipped"),
    OUT_FOR_DELIVERY("Out for Delivery"),
    DELIVERED("Delivered"),
    CANCELLED("Cancelled")
}

data class TrackingStep(
    val status: OrderStatus,
    val date: String,
    val description: String,
    val isCompleted: Boolean,
    val isCurrent: Boolean
)

data class Order(
    val orderId: String,
    val date: String,
    val items: List<CartItem>,
    val subtotal: Double,
    val discount: Double,
    val shipping: Double,
    val tax: Double,
    val total: Double,
    val status: OrderStatus,
    val trackingSteps: List<TrackingStep>,
    val shippingAddress: Address,
    val paymentMethod: String,
    val estimatedDelivery: String
)

data class Coupon(
    val code: String,
    val discountPercentage: Int = 0,
    val fixedDiscount: Double = 0.0,
    val minOrderAmount: Double = 0.0,
    val description: String
)

enum class NotificationType {
    ORDER, DISCOUNT, FLASH_SALE, PROMO, NEW_ARRIVAL
}

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val time: String,
    val type: NotificationType,
    val isRead: Boolean = false
)

data class FaqItem(
    val id: String,
    val question: String,
    val answer: String,
    val category: String = "General"
)

data class ChatMessage(
    val id: String,
    val sender: String, // "user" or "support"
    val message: String,
    val timestamp: String,
    val isUser: Boolean
)
