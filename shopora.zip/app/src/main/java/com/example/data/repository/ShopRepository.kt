package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.datasource.MockData
import com.example.data.model.Address
import com.example.data.model.CartItem
import com.example.data.model.Coupon
import com.example.data.model.NotificationItem
import com.example.data.model.NotificationType
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.Product
import com.example.data.model.TrackingStep
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ShopRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("shopora_prefs", Context.MODE_PRIVATE)

    // In-memory reactive flows
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _wishlistProductIds = MutableStateFlow<Set<String>>(emptySet())
    val wishlistProductIds: StateFlow<Set<String>> = _wishlistProductIds.asStateFlow()

    private val _recentlyViewedIds = MutableStateFlow<List<String>>(emptyList())
    val recentlyViewedIds: StateFlow<List<String>> = _recentlyViewedIds.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _addresses = MutableStateFlow<List<Address>>(MockData.defaultAddresses)
    val addresses: StateFlow<List<Address>> = _addresses.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationItem>>(MockData.initialNotifications)
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    private val _recentSearches = MutableStateFlow<List<String>>(listOf("Headphones", "Linen Shirt", "Running Shoes", "Serum"))
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    private val _appliedCoupon = MutableStateFlow<Coupon?>(null)
    val appliedCoupon: StateFlow<Coupon?> = _appliedCoupon.asStateFlow()

    // User-created products flow
    private val _userProducts = MutableStateFlow<List<Product>>(emptyList())
    val userProducts: StateFlow<List<Product>> = _userProducts.asStateFlow()

    init {
        loadPersistedData()
    }

    private fun loadPersistedData() {
        // Load User Products
        loadUserProducts()

        // Load Wishlist
        val savedWishlist = prefs.getStringSet("wishlist_ids", null)
        if (savedWishlist != null) {
            _wishlistProductIds.value = savedWishlist
        } else {
            // Default seed 2 wishlist items for great first impression
            _wishlistProductIds.value = setOf("p_elec_1", "p_fash_2")
        }

        // Load Cart
        val cartJson = prefs.getString("cart_items_json", null)
        if (cartJson != null) {
            try {
                val array = JSONArray(cartJson)
                val list = mutableListOf<CartItem>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val prodId = obj.getString("productId")
                    val color = obj.optString("color", "")
                    val size = obj.optString("size", "")
                    val qty = obj.optInt("quantity", 1)
                    val prod = MockData.products.find { it.id == prodId }
                    if (prod != null) {
                        list.add(
                            CartItem(
                                id = obj.optString("id", UUID.randomUUID().toString()),
                                product = prod,
                                selectedColor = color,
                                selectedSize = size,
                                quantity = qty
                            )
                        )
                    }
                }
                _cartItems.value = list
            } catch (e: Exception) {
                seedInitialCart()
            }
        } else {
            seedInitialCart()
        }

        // Load Recently Viewed
        val recentJson = prefs.getString("recently_viewed_json", null)
        if (recentJson != null) {
            try {
                val array = JSONArray(recentJson)
                val list = mutableListOf<String>()
                for (i in 0 until array.length()) {
                    list.add(array.getString(i))
                }
                _recentlyViewedIds.value = list
            } catch (e: Exception) {
                _recentlyViewedIds.value = listOf("p_fash_1", "p_shoe_1", "p_wat_1")
            }
        } else {
            _recentlyViewedIds.value = listOf("p_fash_1", "p_shoe_1", "p_wat_1")
        }

        // Load Orders
        loadOrders()
    }

    private fun seedInitialCart() {
        val sample1 = MockData.products.find { it.id == "p_fash_1" }
        val sample2 = MockData.products.find { it.id == "p_elec_3" }
        val list = mutableListOf<CartItem>()
        if (sample1 != null) {
            list.add(CartItem(UUID.randomUUID().toString(), sample1, "Butter Cream", "M", 1))
        }
        if (sample2 != null) {
            list.add(CartItem(UUID.randomUUID().toString(), sample2, "Pearl White", "", 1))
        }
        _cartItems.value = list
        saveCart()
    }

    private fun saveCart() {
        val array = JSONArray()
        _cartItems.value.forEach { item ->
            val obj = JSONObject().apply {
                put("id", item.id)
                put("productId", item.product.id)
                put("color", item.selectedColor)
                put("size", item.selectedSize)
                put("quantity", item.quantity)
            }
            array.put(obj)
        }
        prefs.edit().putString("cart_items_json", array.toString()).apply()
    }

    fun addToCart(product: Product, color: String = "", size: String = "", quantity: Int = 1) {
        val current = _cartItems.value.toMutableList()
        val existingIndex = current.indexOfFirst {
            it.product.id == product.id && it.selectedColor == color && it.selectedSize == size
        }
        if (existingIndex >= 0) {
            val existing = current[existingIndex]
            current[existingIndex] = existing.copy(quantity = existing.quantity + quantity)
        } else {
            current.add(
                CartItem(
                    id = UUID.randomUUID().toString(),
                    product = product,
                    selectedColor = if (color.isEmpty() && product.colors.isNotEmpty()) product.colors.first() else color,
                    selectedSize = if (size.isEmpty() && product.sizes.isNotEmpty()) product.sizes.first() else size,
                    quantity = quantity
                )
            )
        }
        _cartItems.value = current
        saveCart()
    }

    fun updateCartQuantity(cartItemId: String, newQuantity: Int) {
        if (newQuantity <= 0) {
            removeFromCart(cartItemId)
            return
        }
        _cartItems.value = _cartItems.value.map {
            if (it.id == cartItemId) it.copy(quantity = newQuantity) else it
        }
        saveCart()
    }

    fun removeFromCart(cartItemId: String) {
        _cartItems.value = _cartItems.value.filter { it.id != cartItemId }
        saveCart()
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _appliedCoupon.value = null
        saveCart()
    }

    fun toggleWishlist(productId: String) {
        val current = _wishlistProductIds.value.toMutableSet()
        if (current.contains(productId)) {
            current.remove(productId)
        } else {
            current.add(productId)
        }
        _wishlistProductIds.value = current
        prefs.edit().putStringSet("wishlist_ids", current).apply()
    }

    fun isInWishlist(productId: String): Boolean {
        return _wishlistProductIds.value.contains(productId)
    }

    fun recordRecentlyViewed(productId: String) {
        val current = _recentlyViewedIds.value.filter { it != productId }.toMutableList()
        current.add(0, productId)
        val trimmed = current.take(12)
        _recentlyViewedIds.value = trimmed
        val array = JSONArray()
        trimmed.forEach { array.put(it) }
        prefs.edit().putString("recently_viewed_json", array.toString()).apply()
    }

    fun applyCoupon(code: String): Pair<Boolean, String> {
        val found = MockData.coupons.find { it.code.equals(code.trim(), ignoreCase = true) }
        if (found == null) {
            return Pair(false, "Invalid promo code. Try SHOPORA50, WELCOME10, or FLASH20")
        }
        val subtotal = calculateSubtotal()
        if (subtotal < found.minOrderAmount) {
            return Pair(false, "Minimum order amount of $${found.minOrderAmount.toInt()} required for this coupon")
        }
        _appliedCoupon.value = found
        return Pair(true, "Coupon '${found.code}' applied successfully!")
    }

    fun removeCoupon() {
        _appliedCoupon.value = null
    }

    fun calculateSubtotal(): Double {
        return _cartItems.value.sumOf { it.product.price * it.quantity }
    }

    fun calculateDiscount(): Double {
        val subtotal = calculateSubtotal()
        val coupon = _appliedCoupon.value ?: return 0.0
        return when {
            coupon.fixedDiscount > 0 -> coupon.fixedDiscount.coerceAtMost(subtotal)
            coupon.discountPercentage > 0 -> subtotal * (coupon.discountPercentage / 100.0)
            else -> 0.0
        }
    }

    fun calculateShipping(): Double {
        val subtotal = calculateSubtotal()
        return if (subtotal >= 50.0 || subtotal == 0.0) 0.0 else 5.99
    }

    fun calculateTax(): Double {
        val subtotal = calculateSubtotal()
        return (subtotal - calculateDiscount()).coerceAtLeast(0.0) * 0.08
    }

    fun calculateTotal(): Double {
        val subtotal = calculateSubtotal()
        val discount = calculateDiscount()
        val shipping = calculateShipping()
        val tax = calculateTax()
        return (subtotal - discount + shipping + tax).coerceAtLeast(0.0)
    }

    private fun loadOrders() {
        // Initial sample order so order history looks rich and realistic immediately
        val p1 = MockData.products.find { it.id == "p_elec_1" }
        val p2 = MockData.products.find { it.id == "p_acc_1" }
        val initialOrderList = mutableListOf<Order>()
        if (p1 != null && p2 != null) {
            val sampleItems = listOf(
                CartItem(UUID.randomUUID().toString(), p1, "Matte Black", "", 1),
                CartItem(UUID.randomUUID().toString(), p2, "Honey Tortoise", "", 1)
            )
            initialOrderList.add(
                Order(
                    orderId = "SP-849201",
                    date = "Oct 4, 2026",
                    items = sampleItems,
                    subtotal = 207.0,
                    discount = 50.0,
                    shipping = 0.0,
                    tax = 12.56,
                    total = 169.56,
                    status = OrderStatus.DELIVERED,
                    trackingSteps = listOf(
                        TrackingStep(OrderStatus.PENDING, "Oct 4, 10:30 AM", "Order received & payment verified", true, false),
                        TrackingStep(OrderStatus.CONFIRMED, "Oct 4, 11:15 AM", "Order confirmed by merchant", true, false),
                        TrackingStep(OrderStatus.PROCESSING, "Oct 4, 02:45 PM", "Items packed & quality checked", true, false),
                        TrackingStep(OrderStatus.SHIPPED, "Oct 4, 06:20 PM", "Dispatched with Express Courier", true, false),
                        TrackingStep(OrderStatus.OUT_FOR_DELIVERY, "Oct 5, 08:30 AM", "Courier is out for delivery", true, false),
                        TrackingStep(OrderStatus.DELIVERED, "Oct 5, 01:14 PM", "Delivered to front lobby", true, true)
                    ),
                    shippingAddress = MockData.defaultAddresses.first(),
                    paymentMethod = "Credit Card (•••• 4242)",
                    estimatedDelivery = "Delivered on Oct 5"
                )
            )
        }
        _orders.value = initialOrderList
    }

    fun placeOrder(
        customerName: String,
        customerPhone: String,
        address: Address,
        paymentMethod: String,
        notes: String = ""
    ): Order {
        val items = _cartItems.value.toList()
        val subtotal = calculateSubtotal()
        val discount = calculateDiscount()
        val shipping = calculateShipping()
        val tax = calculateTax()
        val total = calculateTotal()

        val sdf = SimpleDateFormat("MMM d, yyyy", Locale.US)
        val todayStr = sdf.format(Date())

        // Estimated delivery in 3 days
        val estDate = SimpleDateFormat("MMM d, yyyy", Locale.US).format(Date(System.currentTimeMillis() + 3L * 24 * 3600 * 1000))

        val orderNum = "SP-" + (100000 + (Math.random() * 900000).toInt())
        val order = Order(
            orderId = orderNum,
            date = todayStr,
            items = items,
            subtotal = subtotal,
            discount = discount,
            shipping = shipping,
            tax = tax,
            total = total,
            status = OrderStatus.CONFIRMED,
            trackingSteps = listOf(
                TrackingStep(OrderStatus.PENDING, "Just now", "Order received and approved", true, false),
                TrackingStep(OrderStatus.CONFIRMED, "Just now", "Order confirmed and queued for fulfillment", true, true),
                TrackingStep(OrderStatus.PROCESSING, "Pending", "Preparing items at fulfillment center", false, false),
                TrackingStep(OrderStatus.SHIPPED, "Estimated $estDate", "Handover to express courier", false, false),
                TrackingStep(OrderStatus.OUT_FOR_DELIVERY, "Estimated $estDate", "Courier vehicle dispatch", false, false),
                TrackingStep(OrderStatus.DELIVERED, "Estimated $estDate", "Arrival at doorstep", false, false)
            ),
            shippingAddress = address,
            paymentMethod = paymentMethod,
            estimatedDelivery = estDate
        )

        val currentOrders = _orders.value.toMutableList()
        currentOrders.add(0, order)
        _orders.value = currentOrders

        // Add a confirmation notification
        val notif = NotificationItem(
            id = UUID.randomUUID().toString(),
            title = "Order #$orderNum Confirmed! 🎉",
            message = "Your order of ${items.size} item(s) has been received. Estimated delivery: $estDate",
            time = "Just now",
            type = NotificationType.ORDER,
            isRead = false
        )
        _notifications.value = listOf(notif) + _notifications.value

        // Clear cart
        clearCart()
        return order
    }

    fun addAddress(address: Address) {
        val current = _addresses.value.toMutableList()
        if (address.isDefault) {
            for (i in current.indices) {
                current[i] = current[i].copy(isDefault = false)
            }
        }
        current.add(address)
        _addresses.value = current
    }

    fun deleteAddress(id: String) {
        _addresses.value = _addresses.value.filter { it.id != id }
    }

    fun setDefaultAddress(id: String) {
        _addresses.value = _addresses.value.map {
            it.copy(isDefault = (it.id == id))
        }
    }

    fun markAllNotificationsRead() {
        _notifications.value = _notifications.value.map { it.copy(isRead = true) }
    }

    fun markNotificationRead(id: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(isRead = true) else it
        }
    }

    fun addSearchQuery(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return
        val current = _recentSearches.value.filter { !it.equals(trimmed, ignoreCase = true) }.toMutableList()
        current.add(0, trimmed)
        _recentSearches.value = current.take(8)
    }

    fun clearSearchHistory() {
        _recentSearches.value = emptyList()
    }

    // User Products Persistence
    private fun loadUserProducts() {
        val json = prefs.getString("user_products_json", null)
        if (json != null) {
            try {
                val array = JSONArray(json)
                val list = mutableListOf<Product>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val id = obj.getString("id")
                    val name = obj.getString("name")
                    val category = obj.getString("category")
                    val price = obj.getDouble("price")
                    val originalPrice = obj.optDouble("originalPrice", price)
                    val discount = obj.optInt("discount", 0)
                    val rating = obj.optDouble("rating", 5.0).toFloat()
                    val reviews = obj.optInt("reviews", 1)
                    val description = obj.optString("description", "")
                    val brand = obj.optString("brand", "Community Seller")
                    val isFeatured = obj.optBoolean("isFeatured", false)
                    val isTrending = obj.optBoolean("isTrending", false)
                    val isBestSeller = obj.optBoolean("isBestSeller", false)
                    val isFlashSale = obj.optBoolean("isFlashSale", false)
                    val stock = obj.optInt("stock", 10)

                    val imagesArray = obj.optJSONArray("images")
                    val images = mutableListOf<String>()
                    if (imagesArray != null) {
                        for (j in 0 until imagesArray.length()) {
                            images.add(imagesArray.getString(j))
                        }
                    }

                    val colorsArray = obj.optJSONArray("colors")
                    val colors = mutableListOf<String>()
                    if (colorsArray != null) {
                        for (j in 0 until colorsArray.length()) {
                            colors.add(colorsArray.getString(j))
                        }
                    }

                    val sizesArray = obj.optJSONArray("sizes")
                    val sizes = mutableListOf<String>()
                    if (sizesArray != null) {
                        for (j in 0 until sizesArray.length()) {
                            sizes.add(sizesArray.getString(j))
                        }
                    }

                    val specsObj = obj.optJSONObject("specifications")
                    val specs = mutableMapOf<String, String>()
                    if (specsObj != null) {
                        val keys = specsObj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            specs[key] = specsObj.getString(key)
                        }
                    }

                    list.add(
                        Product(
                            id = id,
                            name = name,
                            category = category,
                            price = price,
                            originalPrice = originalPrice,
                            discount = discount,
                            rating = rating,
                            reviews = reviews,
                            images = images,
                            description = description,
                            specifications = specs,
                            colors = colors,
                            sizes = sizes,
                            stock = stock,
                            brand = brand,
                            isFeatured = isFeatured,
                            isTrending = isTrending,
                            isBestSeller = isBestSeller,
                            isFlashSale = isFlashSale
                        )
                    )
                }
                _userProducts.value = list
            } catch (e: Exception) {
                _userProducts.value = emptyList()
            }
        }
    }

    private fun saveUserProducts() {
        val array = JSONArray()
        _userProducts.value.forEach { prod ->
            val obj = JSONObject().apply {
                put("id", prod.id)
                put("name", prod.name)
                put("category", prod.category)
                put("price", prod.price)
                put("originalPrice", prod.originalPrice)
                put("discount", prod.discount)
                put("rating", prod.rating.toDouble())
                put("reviews", prod.reviews)
                put("description", prod.description)
                put("brand", prod.brand)
                put("stock", prod.stock)
                put("isFeatured", prod.isFeatured)
                put("isTrending", prod.isTrending)
                put("isBestSeller", prod.isBestSeller)
                put("isFlashSale", prod.isFlashSale)

                val imgArr = JSONArray()
                prod.images.forEach { imgArr.put(it) }
                put("images", imgArr)

                val colArr = JSONArray()
                prod.colors.forEach { colArr.put(it) }
                put("colors", colArr)

                val sizeArr = JSONArray()
                prod.sizes.forEach { sizeArr.put(it) }
                put("sizes", sizeArr)

                val specObj = JSONObject()
                prod.specifications.forEach { (k, v) -> specObj.put(k, v) }
                put("specifications", specObj)
            }
            array.put(obj)
        }
        prefs.edit().putString("user_products_json", array.toString()).apply()
    }

    fun addUserProduct(product: Product) {
        val current = _userProducts.value.toMutableList()
        current.add(0, product)
        _userProducts.value = current
        saveUserProducts()
    }

    fun deleteUserProduct(productId: String) {
        _userProducts.value = _userProducts.value.filter { it.id != productId }
        saveUserProducts()
    }

    fun getAllProducts(): List<Product> {
        return _userProducts.value + MockData.products
    }

    fun getProductById(id: String): Product? {
        return _userProducts.value.find { it.id == id } ?: MockData.products.find { it.id == id }
    }
}
