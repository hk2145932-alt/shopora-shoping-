package com.example.data.datasource

import com.example.data.model.Address
import com.example.data.model.Coupon
import com.example.data.model.FaqItem
import com.example.data.model.NotificationItem
import com.example.data.model.NotificationType
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.data.model.ProductReview

object MockData {

    val categories = listOf(
        ProductCategory("cat_mobiles", "Mobiles", "smartphone", 12),
        ProductCategory("cat_perfume", "Perfumes", "spa", 10),
        ProductCategory("cat_ladies", "Ladies Clothes", "woman", 12),
        ProductCategory("cat_fashion", "Fashion", "checkroom", 10),
        ProductCategory("cat_electronics", "Electronics", "devices", 8),
        ProductCategory("cat_beauty", "Beauty", "face", 6),
        ProductCategory("cat_home", "Home", "home", 6),
        ProductCategory("cat_shoes", "Shoes", "roller_skating", 6),
        ProductCategory("cat_bags", "Bags", "shopping_bag", 5),
        ProductCategory("cat_watches", "Watches", "watch", 5),
        ProductCategory("cat_accessories", "Accessories", "auto_awesome", 6)
    )

    // Dynamic accessor to full catalog in ProductData
    val products: List<Product> get() = ProductData.allProducts

    val coupons = listOf(
        Coupon(
            code = "SHOPORA50",
            fixedDiscount = 50.0,
            minOrderAmount = 150.0,
            description = "$50 OFF on orders above $150"
        ),
        Coupon(
            code = "WELCOME10",
            discountPercentage = 10,
            minOrderAmount = 30.0,
            description = "10% OFF for new shoppers (min $30)"
        ),
        Coupon(
            code = "FLASH20",
            discountPercentage = 20,
            minOrderAmount = 60.0,
            description = "20% OFF Flash Sale discount"
        )
    )

    val defaultAddresses = listOf(
        Address(
            id = "addr_1",
            label = "Home",
            fullName = "Alex Morgan",
            phone = "+1 (555) 234-5678",
            street = "742 Evergreen Terrace, Apt 4B",
            city = "New York",
            province = "NY",
            postalCode = "10001",
            isDefault = true
        ),
        Address(
            id = "addr_2",
            label = "Office",
            fullName = "Alex Morgan",
            phone = "+1 (555) 987-6543",
            street = "350 5th Avenue, Suite 2200",
            city = "New York",
            province = "NY",
            postalCode = "10118",
            isDefault = false
        )
    )

    val sampleReviews = listOf(
        ProductReview(
            id = "rev_1",
            userName = "Sophia Turner",
            rating = 5.0f,
            date = "2 days ago",
            comment = "Exceeded all my expectations! The craftsmanship is top-notch, fits like a dream, and packaging was immaculate. Highly recommend Shopora!"
        ),
        ProductReview(
            id = "rev_2",
            userName = "Marcus Vance",
            rating = 4.8f,
            date = "1 week ago",
            comment = "Arrived in 2 days with standard shipping. Exactly matches the description and photos. Will definitely be buying more from this collection."
        ),
        ProductReview(
            id = "rev_3",
            userName = "Elena Rostova",
            rating = 5.0f,
            date = "2 weeks ago",
            comment = "Unbelievable value for money. The yellow accents in the box and premium feel made it feel like a luxury boutique purchase."
        )
    )

    val initialNotifications = listOf(
        NotificationItem(
            id = "notif_1",
            title = "Flash Sale is Live! ⚡",
            message = "Get up to 50% OFF on premium audio, fashion, and smart watches today.",
            time = "10 mins ago",
            type = NotificationType.FLASH_SALE,
            isRead = false
        ),
        NotificationItem(
            id = "notif_2",
            title = "Special Gift: Code SHOPORA50",
            message = "Enjoy $50 OFF on orders above $150. Use code SHOPORA50 at checkout.",
            time = "2 hours ago",
            type = NotificationType.DISCOUNT,
            isRead = false
        ),
        NotificationItem(
            id = "notif_3",
            title = "Order #SP-849201 Delivered",
            message = "Your package has been placed in your secure lobby parcel box.",
            time = "Yesterday",
            type = NotificationType.ORDER,
            isRead = true
        ),
        NotificationItem(
            id = "notif_4",
            title = "New Arrivals in Electronics",
            message = "Discover the latest ANC headphones, earbuds, and spatial soundbars.",
            time = "2 days ago",
            type = NotificationType.NEW_ARRIVAL,
            isRead = true
        )
    )

    val faqs = listOf(
        FaqItem(
            id = "faq_1",
            question = "How long does standard delivery take?",
            answer = "Standard shipping takes 2 to 4 business days. Orders placed before 2:00 PM EST are dispatched the very same day. Express next-day delivery is also available at checkout.",
            category = "Shipping"
        ),
        FaqItem(
            id = "faq_2",
            question = "What is your return policy?",
            answer = "Shopora offers a hassle-free 30-day money-back guarantee. If you are not 100% satisfied with your purchase, you can initiate a free return from your Orders tab for an instant refund.",
            category = "Returns"
        ),
        FaqItem(
            id = "faq_3",
            question = "What payment methods are supported?",
            answer = "We accept all major Credit/Debit cards (Visa, MasterCard, Amex), Apple Pay, Google Pay, Digital Wallets, and Cash on Delivery (COD) in eligible areas.",
            category = "Payment"
        ),
        FaqItem(
            id = "faq_4",
            question = "Are the products authentic and covered by warranty?",
            answer = "Yes! Every single product on Shopora is 100% authentic, sourced directly from verified authorized brand manufacturers, and backed by a minimum 1-year manufacturer warranty.",
            category = "Warranty"
        ),
        FaqItem(
            id = "faq_5",
            question = "How do I track my active order?",
            answer = "Go to your 'My Orders' screen in the bottom navigation or profile tab. Tap on any order to view real-time timeline steps from dispatch to courier doorstep delivery.",
            category = "Tracking"
        )
    )
}
