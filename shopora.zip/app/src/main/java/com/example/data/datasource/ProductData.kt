package com.example.data.datasource

import com.example.data.model.Product

object ProductData {

    val allProducts: List<Product> = listOf(
        // ==========================================
        // SMARTPHONES & IPHONE MOBILES
        // ==========================================
        Product(
            id = "p_mob_1",
            name = "iPhone 16 Pro Max - Aerospace Grade Titanium",
            category = "Mobiles",
            price = 1199.0,
            originalPrice = 1299.0,
            discount = 8,
            rating = 5.0f,
            reviews = 640,
            images = listOf(
                "https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=800&q=80"
            ),
            description = "The pinnacle of mobile engineering. Strong and light Grade 5 Titanium design with 6.9-inch Super Retina XDR OLED display, ProMotion 120Hz, powerful A18 Pro chip, innovative Camera Control button, and 48MP Fusion camera system with 5x optical telephoto.",
            specifications = mapOf(
                "Display" to "6.9\" Super Retina XDR OLED, 120Hz ProMotion",
                "Processor" to "A18 Pro Chip with 6-core GPU & Apple Intelligence",
                "Cameras" to "48MP Fusion, 48MP Ultra Wide, 12MP 5x Telephoto",
                "Battery" to "Up to 33 hours video playback",
                "Build" to "Grade 5 Titanium with Ceramic Shield front",
                "Connectivity" to "5G, Wi-Fi 7, USB-C 10Gbps Thunderbolt"
            ),
            colors = listOf("Natural Titanium", "Desert Titanium", "White Titanium", "Black Titanium"),
            sizes = listOf("256GB", "512GB", "1TB"),
            stock = 15,
            brand = "Apple",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_mob_2",
            name = "iPhone 16 Pro - 6.3\" ProMotion 120Hz",
            category = "Mobiles",
            price = 999.0,
            originalPrice = 1099.0,
            discount = 9,
            rating = 4.9f,
            reviews = 512,
            images = listOf(
                "https://images.unsplash.com/photo-1591337676887-a217a6970a8a?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Compact flagship powerhouse with textured matte glass and Grade 5 Titanium frame. Boasts the A18 Pro silicon, 5x telephoto optical zoom lens, studio-grade 4-mic array, and tactile Camera Control button.",
            specifications = mapOf(
                "Display" to "6.3\" Super Retina XDR OLED, Always-On Display",
                "Chip" to "A18 Pro with 16-core Neural Engine",
                "Cameras" to "48MP Main, 48MP Ultra Wide, 12MP 5x Telephoto",
                "Weight" to "199 grams"
            ),
            colors = listOf("Desert Titanium", "Natural Titanium", "Black Titanium", "White Titanium"),
            sizes = listOf("128GB", "256GB", "512GB", "1TB"),
            stock = 20,
            brand = "Apple",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_mob_3",
            name = "iPhone 16 - Vibrant Color Infused Ceramic",
            category = "Mobiles",
            price = 799.0,
            originalPrice = 899.0,
            discount = 11,
            rating = 4.9f,
            reviews = 420,
            images = listOf(
                "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Engineered for Apple Intelligence with ultra-durable color-infused back glass. Features new Action Button, Camera Control, 48MP 2-in-1 camera with 2x Telephoto, and next-gen photographic styles.",
            specifications = mapOf(
                "Display" to "6.1\" Super Retina XDR OLED with 2000 nits peak brightness",
                "Chip" to "A18 Chip with 5-core GPU",
                "Cameras" to "48MP Main Camera + 12MP Ultra-Wide Macro",
                "Charging" to "USB-C, MagSafe 25W Fast Wireless"
            ),
            colors = listOf("Ultramarine Blue", "Teal Green", "Bubblegum Pink", "Midnight Black", "Pure White"),
            sizes = listOf("128GB", "256GB", "512GB"),
            stock = 25,
            brand = "Apple",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = true
        ),
        Product(
            id = "p_mob_4",
            name = "iPhone 16 Plus - Large 6.7\" Display & All-Day Battery",
            category = "Mobiles",
            price = 899.0,
            originalPrice = 999.0,
            discount = 10,
            rating = 4.8f,
            reviews = 310,
            images = listOf(
                "https://images.unsplash.com/photo-1580910051074-3eb694886505?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Huge 6.7-inch immersive screen with the longest battery life ever in an iPhone. Powered by the A18 processor with Action Button, Camera Control, and satellite Roadside Assistance.",
            specifications = mapOf(
                "Display" to "6.7\" Super Retina XDR OLED",
                "Battery" to "Up to 27 hours video playback",
                "Cameras" to "48MP Fusion + 12MP Ultra-Wide"
            ),
            colors = listOf("Ultramarine Blue", "Teal Green", "Midnight Black", "Pure White"),
            sizes = listOf("128GB", "256GB", "512GB"),
            stock = 18,
            brand = "Apple",
            isFeatured = false,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_mob_5",
            name = "iPhone 15 Pro - Lightweight Titanium & Action Button",
            category = "Mobiles",
            price = 899.0,
            originalPrice = 999.0,
            discount = 10,
            rating = 4.8f,
            reviews = 485,
            images = listOf(
                "https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Aerospace titanium design, customizable Action Button, A17 Pro 3nm gaming chip, USB 3 transfer speeds, and cinematic 4K60 ProRes video recording.",
            specifications = mapOf(
                "Display" to "6.1\" Super Retina XDR OLED 120Hz",
                "Chip" to "A17 Pro 6-core GPU",
                "Camera" to "48MP Main + 12MP 3x Optical Zoom"
            ),
            colors = listOf("Natural Titanium", "Blue Titanium", "White Titanium", "Black Titanium"),
            sizes = listOf("128GB", "256GB", "512GB"),
            stock = 14,
            brand = "Apple",
            isFeatured = false,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = true
        ),
        Product(
            id = "p_mob_6",
            name = "iPhone 15 - Dynamic Island & Matte Glass",
            category = "Mobiles",
            price = 699.0,
            originalPrice = 799.0,
            discount = 13,
            rating = 4.8f,
            reviews = 390,
            images = listOf(
                "https://images.unsplash.com/photo-1565849904461-04a58ad377e0?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Dynamic Island expands alerts and live activities seamlessly. 48MP main camera captures super high-resolution photos with 2x telephoto optical quality.",
            specifications = mapOf(
                "Display" to "6.1\" Super Retina XDR",
                "Chip" to "A16 Bionic",
                "Port" to "Universal USB-C"
            ),
            colors = listOf("Pastel Blue", "Pastel Pink", "Pastel Green", "Black"),
            sizes = listOf("128GB", "256GB"),
            stock = 22,
            brand = "Apple",
            isFeatured = false,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_mob_7",
            name = "Apple Watch Ultra 2 - Rugged 49mm Titanium GPS+Cellular",
            category = "Mobiles",
            price = 799.0,
            originalPrice = 849.0,
            discount = 6,
            rating = 5.0f,
            reviews = 280,
            images = listOf(
                "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80"
            ),
            description = "The most capable smartwatch. Grade 5 corrosion-resistant titanium case with 3000-nit sapphire crystal display, precision dual-frequency GPS, and 36-hour multi-day endurance.",
            specifications = mapOf(
                "Case" to "49mm Grade 5 Titanium",
                "Water Resistance" to "100m, EN13319 Dive Certified",
                "Sensors" to "Depth Gauge, Water Temp, ECG, Blood Oxygen"
            ),
            colors = listOf("Black Titanium", "Natural Titanium"),
            sizes = listOf("Trail Loop S/M", "Ocean Band", "Alpine Loop L"),
            stock = 12,
            brand = "Apple",
            isFeatured = true,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_mob_8",
            name = "Apple Watch Series 10 - Thinnest Design & Wide-Angle OLED",
            category = "Mobiles",
            price = 399.0,
            originalPrice = 449.0,
            discount = 11,
            rating = 4.9f,
            reviews = 315,
            images = listOf(
                "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Our thinnest watch ever with our largest display. Features glossy Jet Black aluminum, faster charging, sleep apnea notifications, and water depth/temperature sensors.",
            specifications = mapOf(
                "Case" to "46mm Jet Black Polished Aluminum",
                "Display" to "Wide-Angle OLED with 40% brighter off-axis view",
                "Charging" to "0 to 80% in approximately 30 minutes"
            ),
            colors = listOf("Jet Black", "Rose Gold", "Silver"),
            sizes = listOf("42mm", "46mm"),
            stock = 24,
            brand = "Apple",
            isFeatured = true,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = true
        ),
        Product(
            id = "p_mob_9",
            name = "AirPods Pro 2 - Pro Noise Cancelling & USB-C Case",
            category = "Mobiles",
            price = 249.0,
            originalPrice = 279.0,
            discount = 11,
            rating = 4.9f,
            reviews = 890,
            images = listOf(
                "https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Next-level active noise cancellation cancels up to 2x more noise. Adaptive Audio, Transparency mode, Personalized Spatial Audio with dynamic head tracking, and MagSafe USB-C case.",
            specifications = mapOf(
                "Chip" to "Apple H2 Headphone Chip",
                "Battery" to "Up to 6 hours listening (30 hours with case)",
                "Resistance" to "IP54 Dust, sweat, and water resistant"
            ),
            colors = listOf("Gloss White"),
            sizes = emptyList(),
            stock = 45,
            brand = "Apple",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_mob_10",
            name = "MagSafe Slim Italian Leather Case with Camera Control",
            category = "Mobiles",
            price = 42.0,
            originalPrice = 65.0,
            discount = 35,
            rating = 4.8f,
            reviews = 175,
            images = listOf(
                "https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Crafted from specially tanned French leather with built-in aerospace aluminum folding camera ring kickstand and powerful N52 neodymium MagSafe magnets.",
            specifications = mapOf(
                "Compatibility" to "iPhone 16 / 16 Pro / 16 Pro Max",
                "Material" to "Full-Grain European Leather + Aluminum Stand",
                "Drop Protection" to "MIL-STD-810G 10ft Certified"
            ),
            colors = listOf("Cognac Brown", "Midnight Blue", "Forest Green", "Jet Black"),
            sizes = emptyList(),
            stock = 35,
            brand = "Aura Accessories",
            isFeatured = false,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_mob_11",
            name = "3-in-1 Ultra-Thin Foldable MagSafe Fast Charger",
            category = "Mobiles",
            price = 49.0,
            originalPrice = 79.0,
            discount = 38,
            rating = 4.9f,
            reviews = 220,
            images = listOf(
                "https://images.unsplash.com/photo-1622445262464-84b1456045b6?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Ultra-portable aircraft aluminum folding charger. Fast charges iPhone (15W Qi2), Apple Watch Series 10 / Ultra, and AirPods wireless case simultaneously.",
            specifications = mapOf(
                "Power" to "Fast 25W Total Output Qi2 Certified",
                "Design" to "Foldable Pocket Size (Only 14mm thick)",
                "Material" to "CNC Anodized Aluminum + Silicone Pad"
            ),
            colors = listOf("Space Gray", "Silver Frost"),
            sizes = emptyList(),
            stock = 30,
            brand = "PowerPulse",
            isFeatured = false,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = true
        ),
        Product(
            id = "p_mob_12",
            name = "MagSafe 10,000mAh Ultra-Slim Magnetic Power Bank",
            category = "Mobiles",
            price = 45.0,
            originalPrice = 69.0,
            discount = 35,
            rating = 4.8f,
            reviews = 168,
            images = listOf(
                "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Only 9.8mm thin with frosted glass back and digital LED battery percentage readout. Snaps firmly onto iPhone with 15W wireless and 20W PD USB-C pass-through charging.",
            specifications = mapOf(
                "Capacity" to "10,000mAh Lithium Polymer",
                "Wireless Output" to "15W MagSafe Fast Charge",
                "Wired Output" to "20W USB-C Power Delivery"
            ),
            colors = listOf("Frosted Titanium", "Midnight Black", "Pure White"),
            sizes = emptyList(),
            stock = 26,
            brand = "PowerPulse",
            isFeatured = false,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),

        // ==========================================
        // PERFUMES & LUXURY SCENTS
        // ==========================================
        Product(
            id = "p_perf_1",
            name = "Maison Noire Vanilla & Amber Extrait de Parfum",
            category = "Perfumes",
            price = 110.0,
            originalPrice = 165.0,
            discount = 33,
            rating = 4.9f,
            reviews = 245,
            images = listOf(
                "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80"
            ),
            description = "A deeply sensual, hypnotic luxury extrait handcrafted in Grasse, France. Opening with warm bourbon vanilla, heart of golden amber resin, and grounding notes of creamy tonka bean and smoked cedarwood. 18-hour enduring sillage.",
            specifications = mapOf(
                "Concentration" to "Extrait de Parfum (30% Oil)",
                "Top Notes" to "Bourbon Vanilla, Bergamot, Pink Peppercorn",
                "Heart Notes" to "Golden Amber Resin, Heliotrope, Cacao",
                "Base Notes" to "Madagascar Vanilla, Sandalwood, Smoked Cedar",
                "Bottle" to "Hand-Cut Heavy Black Crystal"
            ),
            colors = listOf("50ml Spray", "100ml Flacon"),
            sizes = listOf("50ml", "100ml"),
            stock = 24,
            brand = "Maison Noire",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_perf_2",
            name = "Velvet Rose & Damascus Oud Eau de Parfum",
            category = "Perfumes",
            price = 95.0,
            originalPrice = 140.0,
            discount = 32,
            rating = 4.8f,
            reviews = 182,
            images = listOf(
                "https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=800&q=80"
            ),
            description = "An opulent oriental floral fragrance woven with prized Damascene crimson roses steeped in dark smoky oud, wrapped with toasted praline and clove spices.",
            specifications = mapOf(
                "Concentration" to "Eau de Parfum (20% Oil)",
                "Top Notes" to "Clove, Crisp Pear, Bergamot",
                "Heart Notes" to "Damascene Crimson Rose, Praline",
                "Base Notes" to "Smoky Agarwood (Oud), Amberwood"
            ),
            colors = listOf("Standard 100ml"),
            sizes = listOf("50ml", "100ml"),
            stock = 18,
            brand = "L'Atelier Botanique",
            isFeatured = false,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = true
        ),
        Product(
            id = "p_perf_3",
            name = "Solar Citrus & Neroli Riviera Cologne Intense",
            category = "Perfumes",
            price = 78.0,
            originalPrice = 120.0,
            discount = 35,
            rating = 4.7f,
            reviews = 134,
            images = listOf(
                "https://images.unsplash.com/photo-1615397349754-cfa2066a298e?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Sun-drenched Mediterranean breeze in a bottle. Sparkling Italian mandarin, solar neroli petals, sea salt breeze, and sunlit driftwood.",
            specifications = mapOf(
                "Concentration" to "Cologne Intense (15% Oil)",
                "Top Notes" to "Calabrian Bergamot, Mandarin, Petitgrain",
                "Heart Notes" to "Tunisian Neroli, Orange Blossom",
                "Base Notes" to "Ambergris, Driftwood, White Musk"
            ),
            colors = listOf("Frosted Gold Flacon"),
            sizes = listOf("75ml", "125ml"),
            stock = 28,
            brand = "Riviera Parfums",
            isFeatured = true,
            isTrending = false,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_perf_4",
            name = "Santal Élite Smoked Leather & Cedarwood Extrait",
            category = "Perfumes",
            price = 125.0,
            originalPrice = 185.0,
            discount = 32,
            rating = 4.9f,
            reviews = 196,
            images = listOf(
                "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80"
            ),
            description = "An iconic woody masterpiece. Australian sandalwood melds with cardamom spice, violet leaf, Tuscan leather, and smoky cedarwood.",
            specifications = mapOf(
                "Concentration" to "Extrait de Parfum",
                "Scent Profile" to "Woody, Leather, Warm Spicy",
                "Longevity" to "16+ hours on skin and fabrics"
            ),
            colors = listOf("50ml Flask", "100ml Decanter"),
            sizes = listOf("50ml", "100ml"),
            stock = 14,
            brand = "Maison Noire",
            isFeatured = false,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_perf_5",
            name = "Baccarat Amber Rouge 540 Scent Extrait",
            category = "Perfumes",
            price = 145.0,
            originalPrice = 210.0,
            discount = 31,
            rating = 5.0f,
            reviews = 380,
            images = listOf(
                "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Ethereal crystal radiance. Golden ambergris, jasmine grandiflorum petals, spun brown sugar crystals, and freshly sheared cedarwood. Creates a luminous, intoxicating halo.",
            specifications = mapOf(
                "Concentration" to "Extrait de Parfum (35% Oil)",
                "Top Notes" to "Bitter Almond, Saffron",
                "Heart Notes" to "Egyptian Jasmine, Cedarwood",
                "Base Notes" to "Ambergris, Woody Musks"
            ),
            colors = listOf("Crimson Red Glass 70ml"),
            sizes = listOf("70ml", "120ml"),
            stock = 16,
            brand = "Maison Royale",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_perf_6",
            name = "Royal Pineapple & Silver Birch Eau de Parfum",
            category = "Perfumes",
            price = 135.0,
            originalPrice = 195.0,
            discount = 30,
            rating = 4.9f,
            reviews = 295,
            images = listOf(
                "https://images.unsplash.com/photo-1528722828814-77b9b83aafb2?auto=format&fit=crop&w=800&q=80"
            ),
            description = "The definitive masculine legend. Crisp smoky blackcurrant, juicy royal pineapple, pink berries, silver birchwood, and oakmoss.",
            specifications = mapOf(
                "Concentration" to "Eau de Parfum",
                "Top Notes" to "Pineapple, Bergamot, Blackcurrant",
                "Heart Notes" to "Birch, Patchouli, Moroccan Jasmine",
                "Base Notes" to "Musk, Oakmoss, Ambergris"
            ),
            colors = listOf("100ml Heavy Black Flacon"),
            sizes = listOf("50ml", "100ml"),
            stock = 22,
            brand = "Haute Parfumerie",
            isFeatured = true,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_perf_7",
            name = "Black Opium Noir Roasted Coffee & Floral Parfum",
            category = "Perfumes",
            price = 88.0,
            originalPrice = 130.0,
            discount = 32,
            rating = 4.8f,
            reviews = 265,
            images = listOf(
                "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=800&q=80"
            ),
            description = "An addictive shot of adrenaline. Rich black roasted espresso beans clash with radiant white orange blossom and sensual bourbon vanilla.",
            specifications = mapOf(
                "Concentration" to "Eau de Parfum Intense",
                "Top Notes" to "Black Coffee, Mandarin",
                "Heart Notes" to "Orange Blossom, White Sambac Jasmine",
                "Base Notes" to "Bourbon Vanilla, Patchouli, Cedar"
            ),
            colors = listOf("Glittering Midnight Flask"),
            sizes = listOf("50ml", "90ml"),
            stock = 30,
            brand = "L'Atelier Botanique",
            isFeatured = false,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = true
        ),
        Product(
            id = "p_perf_8",
            name = "English Pear & White Freesia Cologne",
            category = "Perfumes",
            price = 82.0,
            originalPrice = 115.0,
            discount = 29,
            rating = 4.7f,
            reviews = 190,
            images = listOf(
                "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Autumn's golden essence. Freshly gathered crisp King William pears wrapped in a bouquet of cool white freesias and mellowed by amber, patchouli, and woods.",
            specifications = mapOf(
                "Concentration" to "Cologne",
                "Top Notes" to "King William Pear",
                "Heart Notes" to "White Freesia",
                "Base Notes" to "Patchouli, Amber"
            ),
            colors = listOf("Clear Crystal Glass"),
            sizes = listOf("30ml", "100ml"),
            stock = 25,
            brand = "Riviera Parfums",
            isFeatured = false,
            isTrending = false,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_perf_9",
            name = "Tobacco Vanille & Spiced Tonka Gourmand",
            category = "Perfumes",
            price = 130.0,
            originalPrice = 180.0,
            discount = 28,
            rating = 4.9f,
            reviews = 210,
            images = listOf(
                "https://images.unsplash.com/photo-1587017539504-67cfbddac569?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Opulent, warm and iconic. Reminiscent of a private English gentleman's club with aromatic tobacco leaf, oriental spices, creamy vanilla, and cocoa.",
            specifications = mapOf(
                "Concentration" to "Eau de Parfum",
                "Notes" to "Tobacco Leaf, Ginger, Cacao, Tonka Bean, Sweet Wood Sap"
            ),
            colors = listOf("Dark Amber Bottle"),
            sizes = listOf("50ml", "100ml"),
            stock = 15,
            brand = "Maison Noire",
            isFeatured = true,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_perf_10",
            name = "Parisian Lavender & Tonka Bean Nocturne Parfum",
            category = "Perfumes",
            price = 92.0,
            originalPrice = 135.0,
            discount = 32,
            rating = 4.8f,
            reviews = 145,
            images = listOf(
                "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Soothing French blue lavender infused with balsamic tonka bean, roasted almond, and comforting white sandalwood for peaceful evenings.",
            specifications = mapOf(
                "Concentration" to "Parfum Concentré",
                "Longevity" to "12 hours"
            ),
            colors = listOf("Midnight Blue Spray"),
            sizes = listOf("50ml", "100ml"),
            stock = 20,
            brand = "Haute Parfumerie",
            isFeatured = false,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = false
        ),

        // ==========================================
        // LADIES CLOTHES & DRESSES
        // ==========================================
        Product(
            id = "p_lad_1",
            name = "Mulberry Silk Satin Slip Midi Dress",
            category = "Ladies Clothes",
            price = 78.0,
            originalPrice = 125.0,
            discount = 38,
            rating = 4.9f,
            reviews = 310,
            images = listOf(
                "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Cut on the bias for an effortlessly flattering drape. Made from 19mm heavyweight mulberry silk with adjustable dainty spaghetti straps and side slit.",
            specifications = mapOf(
                "Material" to "100% Grade 6A Mulberry Silk",
                "Length" to "Midi (46 inches from shoulder)",
                "Care" to "Hand wash cold or dry clean"
            ),
            colors = listOf("Champagne Gold", "Emerald Green", "Midnight Black", "Ruby Red"),
            sizes = listOf("XS", "S", "M", "L", "XL"),
            stock = 26,
            brand = "Aura Studio",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_lad_2",
            name = "Double-Breasted Structured Tailored Linen Blazer",
            category = "Ladies Clothes",
            price = 92.0,
            originalPrice = 145.0,
            discount = 37,
            rating = 4.8f,
            reviews = 195,
            images = listOf(
                "https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Chic European power dressing. Pure Belgian linen tailored with sharp padded shoulders, peaked lapels, and tortoiseshell horn buttons.",
            specifications = mapOf(
                "Fabric" to "100% Belgian Flax Linen",
                "Lining" to "100% Breathable Cupro",
                "Fit" to "Slightly Oversized Tailored Fit"
            ),
            colors = listOf("Oatmeal Ecru", "Olive Moss", "Jet Black"),
            sizes = listOf("XS", "S", "M", "L"),
            stock = 18,
            brand = "Aura Studio",
            isFeatured = true,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_lad_3",
            name = "Floral Chiffon Tiered Ruffle Maxi Sundress",
            category = "Ladies Clothes",
            price = 68.0,
            originalPrice = 105.0,
            discount = 35,
            rating = 4.8f,
            reviews = 175,
            images = listOf(
                "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Romantic prairie maxi featuring hand-drawn botanical watercolor prints, tiered flutter hem, smocked stretchy bodice, and sweetheart neckline.",
            specifications = mapOf(
                "Material" to "Floaty Chiffon with Rayon Lining",
                "Sleeve" to "Elasticated Puff Cap Sleeve",
                "Fit" to "Fit & Flare Maxi"
            ),
            colors = listOf("Vintage Rose", "Cornflower Blue", "Daisy Yellow"),
            sizes = listOf("S", "M", "L", "XL"),
            stock = 32,
            brand = "L'Atelier Botanique",
            isFeatured = false,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = true
        ),
        Product(
            id = "p_lad_4",
            name = "High-Waisted Wide-Leg Linen Culottes & Trousers",
            category = "Ladies Clothes",
            price = 54.0,
            originalPrice = 85.0,
            discount = 36,
            rating = 4.7f,
            reviews = 142,
            images = listOf(
                "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Breezy comfort meets refined tailoring. High elastic back waistband with front hook-and-bar closure, deep side pockets, and wide palazzo silhouette.",
            specifications = mapOf(
                "Material" to "100% Breathable Organic Linen",
                "Rise" to "High Rise (12 inches)",
                "Inseam" to "30 inches"
            ),
            colors = listOf("Terracotta", "Natural Oatmeal", "Pure White", "Sage Green"),
            sizes = listOf("XS", "S", "M", "L", "XL"),
            stock = 22,
            brand = "Aura Studio",
            isFeatured = false,
            isTrending = false,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_lad_5",
            name = "Pure Cashmere Wrap Cardigan with Self-Tie Belt",
            category = "Ladies Clothes",
            price = 115.0,
            originalPrice = 175.0,
            discount = 34,
            rating = 4.9f,
            reviews = 230,
            images = listOf(
                "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Sumptuous featherweight Mongolian cashmere. Wrap kimono-style front with matching knitted sash belt and ribbed cuff details.",
            specifications = mapOf(
                "Fiber" to "100% Grade A Mongolian Cashmere",
                "Gauge" to "12-Gauge Fine Knit",
                "Care" to "Hand wash cold, dry flat"
            ),
            colors = listOf("Soft Heather Gray", "Buttercream", "Dusty Rose"),
            sizes = listOf("XS", "S", "M", "L"),
            stock = 15,
            brand = "Nordic Weaver",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_lad_6",
            name = "Parisian Pleated A-Line High-Rise Midi Skirt",
            category = "Ladies Clothes",
            price = 49.0,
            originalPrice = 75.0,
            discount = 35,
            rating = 4.7f,
            reviews = 115,
            images = listOf(
                "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Permanent accordion knife pleats swing gently with every step. Concealed side zipper, comfortable stretch waistband, and rich matte satin finish.",
            specifications = mapOf(
                "Material" to "Durable Matte Micro-Satin",
                "Length" to "Midi 32 inches"
            ),
            colors = listOf("Forest Green", "Dusty Pink", "Jet Black"),
            sizes = listOf("S", "M", "L"),
            stock = 28,
            brand = "Aura Studio",
            isFeatured = false,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_lad_7",
            name = "Embroidered French Lace Bell-Sleeve Blouse",
            category = "Ladies Clothes",
            price = 58.0,
            originalPrice = 89.0,
            discount = 35,
            rating = 4.8f,
            reviews = 138,
            images = listOf(
                "https://images.unsplash.com/photo-1564257631407-4deb1f99d992?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Vintage-inspired bohemian elegance. Intricate Guipure lace inserts, delicate scalloped hem, button keyhole back, and airy cotton voile.",
            specifications = mapOf(
                "Fabric" to "100% Organic Cotton Voile & Lace",
                "Details" to "Mother-of-pearl buttons"
            ),
            colors = listOf("Ivory Cream", "Soft Mauve"),
            sizes = listOf("XS", "S", "M", "L"),
            stock = 20,
            brand = "L'Atelier Botanique",
            isFeatured = false,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_lad_8",
            name = "Ribbed Knit Bodycon Sculpt Midi Dress",
            category = "Ladies Clothes",
            price = 62.0,
            originalPrice = 95.0,
            discount = 35,
            rating = 4.8f,
            reviews = 184,
            images = listOf(
                "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Flattering compression ribbed knit sculpts natural curves while offering full flexibility. Square neckline and elegant side leg slit.",
            specifications = mapOf(
                "Material" to "Viscose Elastane Heavyweight Rib",
                "Length" to "Below Knee Midi"
            ),
            colors = listOf("Espresso Brown", "Midnight Black", "Warm Taupe"),
            sizes = listOf("XS", "S", "M", "L"),
            stock = 25,
            brand = "Aura Studio",
            isFeatured = true,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = true
        ),
        Product(
            id = "p_lad_9",
            name = "Classic Double-Breasted Trench Coat with Belt",
            category = "Ladies Clothes",
            price = 135.0,
            originalPrice = 195.0,
            discount = 31,
            rating = 4.9f,
            reviews = 260,
            images = listOf(
                "https://images.unsplash.com/photo-1544022613-e87ca75a784a?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Timeless weatherproof cotton gabardine trench coat. Features stormy weather storm flaps, buckled epaulettes, and horn belt buckle.",
            specifications = mapOf(
                "Fabric" to "Water-Repellent Cotton Gabardine",
                "Lining" to "Satin Tartan Check",
                "Length" to "Long (44 inches)"
            ),
            colors = listOf("Classic Honey Khaki", "Black Onyx", "Deep Olive"),
            sizes = listOf("S", "M", "L", "XL"),
            stock = 16,
            brand = "Haute Couture",
            isFeatured = true,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_lad_10",
            name = "Velvet Cocktail Gala Evening Gown with Slit",
            category = "Ladies Clothes",
            price = 120.0,
            originalPrice = 185.0,
            discount = 35,
            rating = 4.9f,
            reviews = 150,
            images = listOf(
                "https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Stunning formal glamour. Premium plush velvet hugs the silhouette with an asymmetric one-shoulder neckline and high thigh slit.",
            specifications = mapOf(
                "Material" to "Silk-Blend Stretch Velvet",
                "Occasion" to "Gala, Black-Tie, Weddings"
            ),
            colors = listOf("Emerald Green", "Burgundy Wine", "Midnight Sapphire"),
            sizes = listOf("XS", "S", "M", "L"),
            stock = 14,
            brand = "Haute Couture",
            isFeatured = false,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_lad_11",
            name = "Organic Cotton Poplin Oversized Boyfriend Shirt",
            category = "Ladies Clothes",
            price = 46.0,
            originalPrice = 70.0,
            discount = 34,
            rating = 4.7f,
            reviews = 165,
            images = listOf(
                "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Crisp, clean, and effortlessly stylish. 100% organic long-staple cotton poplin with curved high-low hem and classic pointed collar.",
            specifications = mapOf(
                "Material" to "100% Organic Cotton Poplin",
                "Fit" to "Relaxed Boyfriend Fit"
            ),
            colors = listOf("Crisp White", "Sky Blue Stripe", "Pale Pink"),
            sizes = listOf("S", "M", "L", "XL"),
            stock = 30,
            brand = "Aura Studio",
            isFeatured = false,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_lad_12",
            name = "Cozy Cable-Knit Alpaca Blend Cropped Sweater",
            category = "Ladies Clothes",
            price = 74.0,
            originalPrice = 110.0,
            discount = 33,
            rating = 4.8f,
            reviews = 140,
            images = listOf(
                "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Warm chunky knit sweater spun with baby alpaca and wool. Chunky cable details across chest and dropped armholes.",
            specifications = mapOf(
                "Yarn" to "60% Baby Alpaca, 30% Merino Wool, 10% Nylon",
                "Fit" to "Slightly Cropped Boxy"
            ),
            colors = listOf("Cream Vanilla", "Caramel Tan", "Slate Gray"),
            sizes = listOf("XS", "S", "M", "L"),
            stock = 19,
            brand = "Nordic Weaver",
            isFeatured = true,
            isTrending = false,
            isBestSeller = false,
            isFlashSale = false
        ),

        // ==========================================
        // FASHION & MEN'S CLOTHES
        // ==========================================
        Product(
            id = "p_fash_1",
            name = "Minimalist Linen Relaxed Overshirt",
            category = "Fashion",
            price = 48.0,
            originalPrice = 80.0,
            discount = 40,
            rating = 4.8f,
            reviews = 124,
            images = listOf(
                "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Crafted from 100% organic breathable flax linen. Features relaxed drop shoulders, chest patch pocket, and pearlescent buttons. Perfect for effortless daily layering in warm climates.",
            specifications = mapOf(
                "Material" to "100% Organic Linen",
                "Fit" to "Relaxed Boxy Fit",
                "Care" to "Machine wash cold, line dry",
                "Origin" to "Portugal"
            ),
            colors = listOf("Butter Cream", "Sand Olive", "Midnight Black"),
            sizes = listOf("S", "M", "L", "XL"),
            stock = 18,
            brand = "Aura Studio",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_fash_2",
            name = "Cashmere Blend Crewneck Knit",
            category = "Fashion",
            price = 89.0,
            originalPrice = 145.0,
            discount = 38,
            rating = 4.9f,
            reviews = 89,
            images = listOf(
                "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Ultra-soft premium Mongolian cashmere combined with fine merino wool. Ribbed hems, neckline, and cuffs provide structured resilience and enduring warmth.",
            specifications = mapOf(
                "Material" to "70% Merino Wool, 30% Cashmere",
                "Weight" to "280 gsm",
                "Care" to "Dry clean or hand wash cold"
            ),
            colors = listOf("Oatmeal", "Charcoal Gray", "Deep Honey"),
            sizes = listOf("XS", "S", "M", "L"),
            stock = 12,
            brand = "Nordic Weaver",
            isFeatured = true,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = true
        ),
        Product(
            id = "p_fash_3",
            name = "Tailored Wide-Leg Pleated Trousers",
            category = "Fashion",
            price = 64.0,
            originalPrice = 95.0,
            discount = 32,
            rating = 4.7f,
            reviews = 56,
            images = listOf(
                "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1479064555552-3ef4979f8908?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Modern drape with double front knife pleats and an extended tab waistband. Engineered in a wrinkle-resistant wool-blend twill fabric for smart casual refinement.",
            specifications = mapOf(
                "Material" to "55% Wool, 43% Polyester, 2% Elastane",
                "Fit" to "High-rise, wide leg",
                "Pockets" to "Slash front pockets, welt rear pockets"
            ),
            colors = listOf("Dark Olive", "Muted Taupe", "Ink Black"),
            sizes = listOf("28", "30", "32", "34", "36"),
            stock = 25,
            brand = "Atelier Form",
            isFeatured = false,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_clo_1",
            name = "Vintage Washed Japanese Selvedge Denim Jacket",
            category = "Fashion",
            price = 82.0,
            originalPrice = 130.0,
            discount = 37,
            rating = 4.8f,
            reviews = 129,
            images = listOf(
                "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Custom 13.5oz shuttle-loom Japanese red-line selvedge denim. Hand-washed for authentic vintage patina, reinforced with heavy copper rivets.",
            specifications = mapOf(
                "Denim" to "13.5oz Japanese Selvedge Denim",
                "Hardware" to "Custom Antiqued Copper Buttons",
                "Fit" to "Classic Trucker Fit"
            ),
            colors = listOf("Vintage Indigo Wash", "Washed Charcoal"),
            sizes = listOf("S", "M", "L", "XL", "XXL"),
            stock = 17,
            brand = "Heritage Denim",
            isFeatured = false,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_clo_2",
            name = "Superfine Merino Wool Roll-Neck Sweater",
            category = "Fashion",
            price = 72.0,
            originalPrice = 110.0,
            discount = 35,
            rating = 4.9f,
            reviews = 94,
            images = listOf(
                "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Crafted from 19.5-micron extrafine Australian merino wool. Naturally thermoregulating, itch-free, and sleek under a blazer or overcoat.",
            specifications = mapOf(
                "Material" to "100% Extrafine Merino Wool",
                "Knit" to "14-Gauge Ultra-Fine Jersey",
                "Care" to "Hand wash or gentle wool cycle"
            ),
            colors = listOf("Charcoal Heather", "Dark Camel", "Midnight Navy"),
            sizes = listOf("S", "M", "L", "XL"),
            stock = 19,
            brand = "Nordic Weaver",
            isFeatured = false,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_clo_3",
            name = "Heavyweight French Terry Boxy Streetwear Hoodie",
            category = "Fashion",
            price = 58.0,
            originalPrice = 90.0,
            discount = 36,
            rating = 4.9f,
            reviews = 210,
            images = listOf(
                "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=800&q=80"
            ),
            description = "450gsm dense 100% combed cotton French terry. Dropped shoulder streetwear cut with double-layered hood without drawstrings.",
            specifications = mapOf(
                "Weight" to "450 GSM Heavyweight French Terry",
                "Details" to "Seamless kangaroo pocket, thick ribbed hem"
            ),
            colors = listOf("Washed Bone", "Vintage Washed Black", "Pine Green"),
            sizes = listOf("S", "M", "L", "XL", "XXL"),
            stock = 35,
            brand = "Atelier Form",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_clo_4",
            name = "Japanese Selvedge Raw Denim Slim Tapered Jeans",
            category = "Fashion",
            price = 85.0,
            originalPrice = 135.0,
            discount = 37,
            rating = 4.8f,
            reviews = 158,
            images = listOf(
                "https://images.unsplash.com/photo-1542272604-780c96856592?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Unwashed 14oz raw selvedge denim from Okayama. Custom leather waistband patch, donut buttons, and pink chainstitched hem.",
            specifications = mapOf(
                "Denim" to "14oz Okayama Shuttle Loom Denim",
                "Cut" to "Slim Tapered"
            ),
            colors = listOf("Raw Deep Indigo"),
            sizes = listOf("30x32", "32x32", "34x32", "36x34"),
            stock = 18,
            brand = "Heritage Denim",
            isFeatured = false,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_clo_5",
            name = "Wool Cashmere Classic Double-Breasted Overcoat",
            category = "Fashion",
            price = 145.0,
            originalPrice = 220.0,
            discount = 34,
            rating = 4.9f,
            reviews = 185,
            images = listOf(
                "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Sharp architectural silhouette tailored in an 80/20 Italian wool-cashmere blend. Wide notch lapels and back vent.",
            specifications = mapOf(
                "Composition" to "80% Virgin Wool, 20% Cashmere",
                "Lining" to "Satin Bemberg Cupro"
            ),
            colors = listOf("Camel", "Charcoal Gray", "Midnight Navy"),
            sizes = listOf("38R", "40R", "42R", "44R"),
            stock = 12,
            brand = "Nordic Weaver",
            isFeatured = true,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),

        // ==========================================
        // ELECTRONICS
        // ==========================================
        Product(
            id = "p_elec_1",
            name = "AeroSound Pro Hybrid ANC Headphones",
            category = "Electronics",
            price = 149.0,
            originalPrice = 220.0,
            discount = 32,
            rating = 4.9f,
            reviews = 312,
            images = listOf(
                "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Engineered with custom 40mm bio-cellulose drivers, 45dB hybrid active noise cancellation, transparency audio mode, and 60 hours continuous playtime on a single fast charge.",
            specifications = mapOf(
                "Drivers" to "40mm Custom Bio-Cellulose",
                "Battery" to "60 Hours (ANC On)",
                "Bluetooth" to "5.3 with LDAC & AAC",
                "Weight" to "240g"
            ),
            colors = listOf("Matte Black", "Cream Gold", "Slate Silver"),
            sizes = emptyList(),
            stock = 20,
            brand = "AeroSound",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_elec_2",
            name = "Horizon 4K Ultra-Short-Throw Laser Projector",
            category = "Electronics",
            price = 499.0,
            originalPrice = 750.0,
            discount = 33,
            rating = 4.8f,
            reviews = 68,
            images = listOf(
                "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Transform your living room into an IMAX theater. Projects up to 150 inches from only 9 inches away from the wall with true 4K HDR10+ and Dolby Atmos acoustic tuning.",
            specifications = mapOf(
                "Resolution" to "4K UHD (3840 x 2160)",
                "Brightness" to "2400 ANSI Lumens",
                "Audio" to "Built-in Harmon Kardon 30W"
            ),
            colors = listOf("Space Gray", "Silver Frost"),
            sizes = emptyList(),
            stock = 7,
            brand = "LumaVision",
            isFeatured = false,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = true
        ),
        Product(
            id = "p_elec_3",
            name = "Ergonomic Mechanical Wireless Keyboard",
            category = "Electronics",
            price = 85.0,
            originalPrice = 120.0,
            discount = 29,
            rating = 4.7f,
            reviews = 143,
            images = listOf(
                "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Gasket-mounted hot-swappable switches with sound-dampening silicone sheets. CNC anodized aluminum case with RGB per-key backlighting and dual-mode 2.4GHz/Bluetooth.",
            specifications = mapOf(
                "Switches" to "Pre-lubed Gateron Yellow Linear",
                "Keycaps" to "Double-shot PBT Cherry Profile",
                "Battery" to "4000mAh (Up to 200 hours)"
            ),
            colors = listOf("Retro Cream", "Cyberpunk Violet", "Monochrome Dark"),
            sizes = emptyList(),
            stock = 32,
            brand = "KeyLab",
            isFeatured = false,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),

        // ==========================================
        // BEAUTY
        // ==========================================
        Product(
            id = "p_beau_1",
            name = "HydraLuxe Bio-Ceramide Deep Barrier Serum",
            category = "Beauty",
            price = 36.0,
            originalPrice = 55.0,
            discount = 35,
            rating = 4.9f,
            reviews = 428,
            images = listOf(
                "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1608248597359-5975e53e4b77?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Formulated with 5 essential skin-identical ceramides, multi-weight hyaluronic acid, and centella asiatica to repair compromised barriers and restore radiant moisture glow.",
            specifications = mapOf(
                "Volume" to "50ml / 1.7 fl oz",
                "Skin Type" to "Sensitive, Dry, Combination",
                "Free From" to "Fragrance, Alcohol, Parabens"
            ),
            colors = listOf("Standard 50ml", "Value 100ml"),
            sizes = listOf("50ml", "100ml"),
            stock = 45,
            brand = "Aura Pure",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),
        Product(
            id = "p_beau_2",
            name = "Botanical Overnight Renewal Peptide Cream",
            category = "Beauty",
            price = 44.0,
            originalPrice = 68.0,
            discount = 35,
            rating = 4.8f,
            reviews = 189,
            images = listOf(
                "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Infused with plant-derived bakuchiol (gentle retinol alternative), copper tripeptides, and cold-pressed squalane. Visibly firms, smooths fine lines, and nourishes overnight.",
            specifications = mapOf(
                "Size" to "60g",
                "Texture" to "Rich velvety whipped balm",
                "Dermatologist Tested" to "Yes"
            ),
            colors = emptyList(),
            sizes = listOf("60g"),
            stock = 27,
            brand = "Botanique Lab",
            isFeatured = false,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = true
        ),

        // ==========================================
        // HOME & KITCHEN
        // ==========================================
        Product(
            id = "p_home_1",
            name = "Nordic Minimalist Matte Ceramic Pour-Over Set",
            category = "Home",
            price = 42.0,
            originalPrice = 65.0,
            discount = 35,
            rating = 4.8f,
            reviews = 97,
            images = listOf(
                "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Handmade stoneware dripper and matching 600ml glass carafe with raw walnut wooden collar. Engineered with interior spiral ribs for optimal coffee extraction rate.",
            specifications = mapOf(
                "Capacity" to "600ml (2-4 cups)",
                "Material" to "Heat-resistant borosilicate & ceramic",
                "Filter Type" to "Standard V60 02 paper filters"
            ),
            colors = listOf("Matte Chalk White", "Basalt Black", "Terracotta"),
            sizes = emptyList(),
            stock = 19,
            brand = "Nordic Artisan",
            isFeatured = true,
            isTrending = false,
            isBestSeller = false,
            isFlashSale = false
        ),
        Product(
            id = "p_home_2",
            name = "Sculptural Wabi-Sabi Table Lamp with Dimmer",
            category = "Home",
            price = 79.0,
            originalPrice = 125.0,
            discount = 37,
            rating = 4.9f,
            reviews = 112,
            images = listOf(
                "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Organic clay pedestal with coarse textured sand finish paired with an ivory linen lampshade. Includes stepless rotary brass dimmer knob for cozy ambient evening light.",
            specifications = mapOf(
                "Dimensions" to "Height 38cm, Diameter 26cm",
                "Bulb" to "E26 Warm 2700K Dimmable LED included",
                "Cord" to "Braided fabric cord 1.8m"
            ),
            colors = listOf("Limestone White", "Sand Ochre"),
            sizes = emptyList(),
            stock = 14,
            brand = "Terra Studio",
            isFeatured = false,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        ),

        // ==========================================
        // SHOES
        // ==========================================
        Product(
            id = "p_shoe_1",
            name = "Velocity Cloudform Cushion Running Sneakers",
            category = "Shoes",
            price = 84.0,
            originalPrice = 135.0,
            discount = 38,
            rating = 4.9f,
            reviews = 340,
            images = listOf(
                "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Engineered supercritical foam midsole provides 82% explosive energy return with zero joint fatigue. Seamless Jacquard breathable mesh upper hugs foot comfortably.",
            specifications = mapOf(
                "Weight" to "215g (Size 9)",
                "Drop" to "8mm Heel-to-Toe Drop",
                "Outsole" to "Continental Grip Rubber"
            ),
            colors = listOf("Sonic Red", "Glacier White", "Phantom Black"),
            sizes = listOf("US 7", "US 8", "US 9", "US 10", "US 11", "US 12"),
            stock = 38,
            brand = "Velocity Athletics",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = true
        ),

        // ==========================================
        // BAGS
        // ==========================================
        Product(
            id = "p_bag_1",
            name = "Verona Full-Grain Leather Minimalist Tote",
            category = "Bags",
            price = 118.0,
            originalPrice = 185.0,
            discount = 36,
            rating = 4.9f,
            reviews = 205,
            images = listOf(
                "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Handcrafted from vegetable-tanned Tuscan leather that develops a magnificent personal patina over time. Fits a 15-inch laptop, tablet, water bottle, and daily essentials.",
            specifications = mapOf(
                "Dimensions" to "38 x 32 x 14 cm",
                "Hardware" to "Solid brushed brass",
                "Interior" to "Padded laptop sleeve & zipped pocket"
            ),
            colors = listOf("Cognac Tan", "Espresso", "Black Onyx"),
            sizes = emptyList(),
            stock = 15,
            brand = "Verona Atelier",
            isFeatured = true,
            isTrending = false,
            isBestSeller = true,
            isFlashSale = false
        ),

        // ==========================================
        // WATCHES
        // ==========================================
        Product(
            id = "p_wat_1",
            name = "Krono Bauhaus Minimalist Automatic Watch",
            category = "Watches",
            price = 159.0,
            originalPrice = 240.0,
            discount = 34,
            rating = 4.9f,
            reviews = 156,
            images = listOf(
                "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=800&q=80",
                "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Inspired by 1920s German Bauhaus geometry. Japanese Miyota 9015 mechanical movement with exhibition sapphire caseback, heat-blued steel hands, and Horween leather strap.",
            specifications = mapOf(
                "Case Diameter" to "39mm 316L Stainless Steel",
                "Crystal" to "Domed Anti-Reflective Sapphire",
                "Water Resistance" to "50 Meters (5 ATM)"
            ),
            colors = listOf("Silver / White Dial", "Rose Gold / Sunray Blue"),
            sizes = emptyList(),
            stock = 11,
            brand = "Krono Horology",
            isFeatured = true,
            isTrending = true,
            isBestSeller = false,
            isFlashSale = false
        ),

        // ==========================================
        // ACCESSORIES
        // ==========================================
        Product(
            id = "p_acc_1",
            name = "Polarized Titanium Aviator Sunglasses",
            category = "Accessories",
            price = 55.0,
            originalPrice = 90.0,
            discount = 39,
            rating = 4.8f,
            reviews = 142,
            images = listOf(
                "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80"
            ),
            description = "Featherweight Japanese beta-titanium frame weighing only 16 grams. High-contrast Category 3 polarized nylon lenses with 100% UVA/UVB protection and anti-scratch coating.",
            specifications = mapOf(
                "Frame Material" to "100% Beta-Titanium",
                "Lens" to "Category 3 Polarized Nylon",
                "Weight" to "16 grams"
            ),
            colors = listOf("Brushed Gold / G15 Green", "Gunmetal / Gradient Smoke"),
            sizes = emptyList(),
            stock = 34,
            brand = "Solara Eyewear",
            isFeatured = true,
            isTrending = true,
            isBestSeller = true,
            isFlashSale = false
        )
    )
}
