package com.example.data.model

data class Product(
    val id: String,
    val name: String,
    val category: String,
    val price: Double,
    val originalPrice: Double,
    val discount: Int,
    val rating: Float,
    val reviews: Int,
    val images: List<String>,
    val description: String,
    val specifications: Map<String, String>,
    val colors: List<String> = emptyList(),
    val sizes: List<String> = emptyList(),
    val stock: Int = 10,
    val brand: String,
    val isFeatured: Boolean = false,
    val isTrending: Boolean = false,
    val isBestSeller: Boolean = false,
    val isFlashSale: Boolean = false
)

data class ProductCategory(
    val id: String,
    val name: String,
    val iconName: String,
    val itemCount: Int
)

data class ProductReview(
    val id: String,
    val userName: String,
    val userAvatar: String = "",
    val rating: Float,
    val date: String,
    val comment: String
)
