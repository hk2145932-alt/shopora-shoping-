package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.datasource.MockData
import com.example.data.model.Address
import com.example.data.repository.ShopRepository
import com.example.viewmodel.ShopViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var repository: ShopRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext<Context>()
        repository = ShopRepository(context)
    }

    @Test
    fun `verify app name resource is Shopora`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Shopora", appName)
    }

    @Test
    fun `verify product catalog has expanded products including perfumes, mobiles, and ladies clothes`() {
        assertTrue("Product count should be >= 40", MockData.products.size >= 40)
        assertTrue("Categories count should be >= 10", MockData.categories.size >= 10)

        val uniqueCategories = MockData.products.map { it.category }.distinct()
        assertTrue("Categories should include Perfumes", uniqueCategories.contains("Perfumes"))
        assertTrue("Categories should include Mobiles", uniqueCategories.contains("Mobiles"))
        assertTrue("Categories should include Ladies Clothes", uniqueCategories.contains("Ladies Clothes"))
    }

    @Test
    fun `verify cart additions and subtotal calculation`() {
        repository.clearCart()
        assertEquals(0, repository.cartItems.value.size)

        val product1 = MockData.products.first()
        repository.addToCart(product1, color = "Black", size = "M", quantity = 2)

        assertEquals(1, repository.cartItems.value.size)
        assertEquals(2, repository.cartItems.value.first().quantity)
        assertEquals(product1.price * 2, repository.calculateSubtotal(), 0.01)

        // Update quantity
        val cartItemId = repository.cartItems.value.first().id
        repository.updateCartQuantity(cartItemId, 3)
        assertEquals(3, repository.cartItems.value.first().quantity)
        assertEquals(product1.price * 3, repository.calculateSubtotal(), 0.01)

        // Remove from cart
        repository.removeFromCart(cartItemId)
        assertEquals(0, repository.cartItems.value.size)
    }

    @Test
    fun `verify wishlist toggle functionality`() {
        val prodId = "test_product_1"
        assertFalse(repository.isInWishlist(prodId))

        repository.toggleWishlist(prodId)
        assertTrue(repository.isInWishlist(prodId))

        repository.toggleWishlist(prodId)
        assertFalse(repository.isInWishlist(prodId))
    }

    @Test
    fun `verify coupon application`() {
        repository.clearCart()
        val expensiveProduct = MockData.products.find { it.price >= 100.0 } ?: MockData.products.first()
        repository.addToCart(expensiveProduct, quantity = 2) // subtotal > 150

        val (success, message) = repository.applyCoupon("SHOPORA50")
        assertTrue(success)
        assertEquals(50.0, repository.calculateDiscount(), 0.01)

        // Test invalid coupon
        val (failSuccess, _) = repository.applyCoupon("INVALID_CODE")
        assertFalse(failSuccess)
    }

    @Test
    fun `verify order placement clears cart and creates tracking steps`() {
        repository.clearCart()
        val product = MockData.products.first()
        repository.addToCart(product, quantity = 1)
        assertEquals(1, repository.cartItems.value.size)

        val address = Address(
            id = "test_addr",
            label = "Home",
            fullName = "Alex Morgan",
            phone = "+1 555-1234",
            street = "123 Main St",
            city = "New York",
            province = "NY",
            postalCode = "10001",
            isDefault = true
        )

        val order = repository.placeOrder(
            customerName = "Alex Morgan",
            customerPhone = "+1 555-1234",
            address = address,
            paymentMethod = "Credit Card"
        )

        assertNotNull(order)
        assertTrue(order.orderId.startsWith("SP-"))
        assertEquals(0, repository.cartItems.value.size) // Cart is cleared
        assertTrue(order.trackingSteps.isNotEmpty())
        assertEquals("Alex Morgan", order.shippingAddress.fullName)
    }

    @Test
    fun `verify search finds iphone with and without spaces`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = ShopViewModel(app)

        val results1 = viewModel.searchProducts("iphone")
        assertTrue("Searching 'iphone' should return products", results1.isNotEmpty())
        assertTrue(results1.any { it.name.contains("iPhone", ignoreCase = true) })

        val results2 = viewModel.searchProducts("i phone")
        assertTrue("Searching 'i phone' should return products", results2.isNotEmpty())
        assertTrue(results2.any { it.name.contains("iPhone", ignoreCase = true) })
    }

    @Test
    fun `verify search finds perfumes and fragrances`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = ShopViewModel(app)

        val results = viewModel.searchProducts("perfume")
        assertTrue("Searching 'perfume' should return fragrance products", results.isNotEmpty())
        assertTrue(results.any { it.category == "Perfumes" })
    }

    @Test
    fun `verify search finds ladies clothes and dresses`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = ShopViewModel(app)

        val results = viewModel.searchProducts("dress")
        assertTrue("Searching 'dress' should return dresses", results.isNotEmpty())
        assertTrue(results.any { it.name.contains("Dress", ignoreCase = true) })

        val resultsBlazer = viewModel.searchProducts("blazer")
        assertTrue("Searching 'blazer' should return blazer", resultsBlazer.isNotEmpty())
        assertTrue(resultsBlazer.any { it.name.contains("Blazer", ignoreCase = true) })
    }
}
